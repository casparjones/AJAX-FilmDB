<?php
/* FilmDB (based on php4flicks) */

	// rss.php -- display rss feed of the 10 newest movies
	
	require_once('../config/config.php');
	
	// RSS refresh in minutes
	$refresh = 720;

	// columns to be listed
	$cols = ' DISTINCT CONCAT(cat,nr)as nr,movies.name,local,year,runtime,medium,movies.id,fid,container,disks,type,video,audio,lang,ratio,format,channel,herz,width,height,country,rating,avail,lentto,lentsince,inserted,aka,cat,genre,comment ';

	// check if user is logged in
	$loggedin = false; $loging = 0; $loguser = '';

	// default query (overwritten below if filter posted)
	$query = "SELECT SQL_CALC_FOUND_ROWS $cols FROM movies ";
		
		$via_GET = true; 
		$cfg['rssentries'] = '10';
		$_POST['page'] = '0';
		$_POST['view'] = 'list';
		$_POST['filtertitle'] = '*';
		$_POST['filter'] = '';
		$_POST['sortby'][0] = 'inserted DESC';
		$_POST['sortby'][1] = 'nr ASC';
		$_POST['sortby'][2] = 'year ASC';
		$_POST['sorter'] = 'inserted_DESC';
		$_POST['genres'] = '';
		$_POST['tosearch'] = '';
		$_POST['searchin'] = 'movies.name,aka';
		
		if(strlen($_POST['filter'])>0){
			if(substr($_POST['filter'],0,38) != 'SELECT SQL_CALC_FOUND_ROWS _COLS_ FROM')
				die('don\'t try that.');
			$query = str_replace('_COLS_',$cols,$_POST['filter']);
		}
		if(sizeof($_POST['sortby'])>0){
			$sortsize = sizeof($_POST['sortby']);
			for($i=0; $i<$sortsize; $i++){
				$sortarray[$i] = $_POST['sortby'][$i];
				if($sortarray[$i]=='') break;
			}
			for($j=0; $j<$sortsize-$i; $j++){
				if(!isset($cfg['defaultsort'][$j])) break;
				$sortarray[$i] = $cfg['defaultsort'][$j];
				$i++;
			}
		} else {
			$sortarray = $cfg['defaultsort'];
		}

		$sortsize = sizeof($sortarray);
		$sortby = implode($sortarray,',');
		$query .= " ORDER BY $sortby ";
	
	// LIMIT clause
	if(!isset($_POST['page']) || $_POST['page'] == '') {
		$_POST['page'] = '0';
	}

	$query .= ' LIMIT '.$_POST['page'].','.$cfg['rssentries'];
	
	$result = mysql_query($query) or die(mysql_error());
	
	$rowresult = mysql_query('SELECT FOUND_ROWS()') or die(mysql_error());
	$row = mysql_fetch_row($rowresult);
	$rowcount = $row[0];
	
	if (@$_SERVER['HTTP_REFERER'] != "") {
		$serverpath = dirname($_SERVER["HTTP_REFERER"]);
	} else {
		$serverpath = dirname($_SERVER["SCRIPT_URI"]);
	}
	$serverpath = ereg_replace("rss",'', $serverpath);
	
header("Content-Type: text/xml; charset=$rsstype");
echo '<?xml version="1.0" encoding="'.$rsstype.'"?>'."\n";
echo '<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/">'."\n";
echo "	<channel>\n";
echo "		<title>".$trans['page_title']."</title>\n";
echo "		<description>".$trans['rss_title']."</description>\n";
echo "		<link>".$serverpath."</link>\n";
echo "		<ttl>".$refresh."</ttl>\n";
echo "		<language>".$cfg['language']."</language>\n";
echo "		<lastBuildDate>".gmdate("r",time())."</lastBuildDate>\n";
echo "		<image>\n";
echo "			<title>".$trans['page_title']."</title>\n";
echo "			<link>".$serverpath."</link>\n";
echo "			<url>".$serverpath."/images/filmdb.png</url>\n";
echo "		</image>\n";
if($rowcount!=0){
	while($row = mysql_fetch_array($result)){
		echo "		<item>\n";
		if($row['local']!=$row['name']) {
			echo "			<title>".$row['name']." (".$row['local'].")</title>\n";
		} else {
			echo "			<title>".$row['name']."</title>\n";
		}
		echo "			<link>http://www.imdb.com/title/tt".$row['id']."</link>\n";
		echo "			<description>".$row['country']." / ".$row['year']." / ".$row['runtime']." ".$trans['t_minutes']." / ".$row['disks']." x ".$row['medium']." / ".substr($row['inserted'], -2, 2).'-'.substr($row['inserted'], 5, 2).'-'.substr($row['inserted'], 0, 4)."</description>\n";
		echo "			<pubDate>".gmdate("r",time())."</pubDate>\n";
		echo "			<guid>http://www.imdb.com/title/tt".$row['id']."</guid>\n";
		echo "		</item>\n";
	}
}
echo "	</channel>\n";
echo "</rss>\n";
?>