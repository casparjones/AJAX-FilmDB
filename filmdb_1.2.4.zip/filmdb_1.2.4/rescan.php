<?php
/* FilmDB (based on php4flicks) */

// delete.php - delete film from db

session_start();
// if(!isset($_SESSION['user'])){
// }

/*	rescan.php - get information from imdb and display it. 
	pml fetch class is used to fetch data from imdb. 
	available vars of doFetch():

	"Title",			string
	"Year",				int
	"Poster",			url
	"Director",			array of array(string'id',string'name')
	"Credits",			array of array(string'id',string'name')
	"Genre",			array of string
	"Rating",			int (real)
	"Starring",			array of array(string'id',string'name')
	"Plot",				string 
	"Release",			date (1999-03-07)
	"Runtime",			int
	"imdbid",			string
	"aka",				string
	"Country"			string
*/

require_once('config/config.php');
require_once('imdb/fetch_movie.php');

$FetchClass = new fetch_movie($cfg['searchLimit'],$cfg['actorLimit']);

// <a target="mainframe" href="rescan.php?action=rescan&fid=000&FetchID=0371626"></a>

switch($_GET['action']) {
	case 'rescan':
	
		// get data
		$result = mysql_query('SELECT name,local,aka,cat,nr,id,runtime,year,genre,container,disks,type,video,audio,lang,ratio,format,medium,channel,herz,width,height,country,rating,avail,lentto,lentsince,comment FROM movies WHERE fid=\''.$_GET['fid'].'\'') or die(mysql_error());
		$row = mysql_fetch_array($result);
		$title = htmlspecialchars($row['name']);
		$local = htmlspecialchars($row['local']);
		$aka = htmlspecialchars($row['aka']);
		$country = htmlspecialchars($row['country']);
		$year = $row['year'];
		$imdbid = $row['id'];
		$fid = $_GET['fid'];
		$runtime = $row['runtime'];
		$cat = $row['cat'];
		$nr = $row['nr'];
		$slang = explode(',',$row['lang']);
		$sgenre = explode(',',$row['genre']);
		$smedium = $row['medium'];
		$sformat = $row['format'];
		$sratio = $row['ratio'];
		$saudio = $row['audio'];
		$stype = $row['type'];
		$scontainer = $row['container'];
		$svideo = $row['video'];
		$schannel = $row['channel'];
		$sherz = $row['herz'];
		$width = $row['width'];
		$height = $row['height'];
		$disks = $row['disks'];
		$rating = $row['rating'];
		$avail = $row['avail'];
		$lentsince = $row['lentsince'];
		$lentto = $row['lentto'];
		$comment = $row['comment'];
		$setposter = false;
		//directors,actors,writers:
		$director = getpeople('directs');
		$writer = getpeople('writes');
		$actor = getpeople('plays_in');
	
		// get all the imdb data and display it
		if($FetchClass->FetchID=='') $FetchClass->FetchID=$imdbid;
		if($FetchClass->FetchID=='') die($trans['add_search_error']);

		// IMDB ID
		$FetchClass->DoFetch($imdbid,'imdbid');
		//title
		$FetchClass->DoFetch($title,'Title');
		//year
		$FetchClass->DoFetch($year,'Year');
		//poster
		if($FetchClass->DoFetch($poster,'Poster') == PML_FETCH_OK){
			//fetch poster: (=>$_SESSION['image'][_movieid_])
			if (function_exists('gd_info')) {
				$ver = gd_info();
				preg_match('/\d/', $ver['GD Version'], $match);
				if ($match[0]>=2){
					include('fetchimggd.php');
				}else {
					include('fetchimg.php');
				}
			}else {
				include('fetchimg.php');
			}
			fetchimg($imdbid,$poster);
			$setposter = true;
		} else {
			$setposter = false;
		}
		//director
		$FetchClass->DoFetch($director,'Director');
		//credits
		$FetchClass->DoFetch($writer,'Credits');
		//runtime
		$FetchClass->DoFetch($runtime,'Runtime');
		//country
		$FetchClass->DoFetch($country,'Country');
		//rating
		$FetchClass->DoFetch($rating,'Rating');
		//actors
		$FetchClass->DoFetch($actor,'Starring');
		// alternative titles
		$FetchClass->DoFetch($aka,'aka');
		// genres
		$FetchClass->DoFetch($sgenre,'Genre');
		// now show it!
		$referer= 'rescan.php?';

		$new_title =  rawurlencode($row['name']); // str_replace("'",'',$title);
		$new_local =  rawurlencode($row['local']); // str_replace("'",'',$local);
		$b_back 	= "parent.window.document.remember.submit();";
		$b_cancel 	= "parent.window.document.remember.submit();";
		$b_rescan 	= "show_Request(true,'editreq','rescanfilm.php?fid=".$fid."&title=".$new_title."&local=".$new_local."')";
		$b_delete 	= "show_Request(true,'editreq','deletefilm.php?fid=".$fid."&title=".$new_title."&local=".$new_local."')";
		$b_save 	= "document.data.action='update.php';if(check()){document.data.submit();this.onclick='return false';show_Request(true,'editreq','updatefilm.php?title=".$new_title."&local=".$new_local."');}";

		include('filmform.php');
		break;
		
	case 'reload':
		// if this is set, filmform gets its data from POST array
		$reload = true;
		include('filmform.php');
		
	default: break;
}
function getpeople($table){
	global $fid;
	$out = array();
	$res = mysql_query("SELECT people.id,people.name FROM $table,people WHERE $table.movie_fid =$fid AND $table.people_id = people.id ORDER BY people.id") or die(mysql_error());
	while($row = mysql_fetch_row($res)){
		$out[] = array('id'=>$row[0], 'name'=>$row[1]); 
	}
	return $out;
}
?>
