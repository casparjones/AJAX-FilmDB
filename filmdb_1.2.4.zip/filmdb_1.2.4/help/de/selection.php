<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<h2><b>Fixe Vorauswahlen</b></h2><br>
		Wenn Sie im <b>IFrame</b> die untere, fixe <b>Funktionsleiste</b> bedienen,
		stehen Ihnen im rechten Bereich nachfolgenden M&ouml;glichkeiten zur Verf&uuml;gung:<br>
		<span class="tooltype"><small>Die aktuelle Auswahl ist jeweils BLAU hinterlegt.</small></span>
		<br>
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<img src="help/de/images/select_area.png" alt="Select" width="525" height="20" border="0">
			</td></tr><td class="txt">
			<dl>
				<dt><big><b>Alle</b></big></dt>
				<dd>
				<b>Generelle Auflistung aller in der Datenbank befindlichen Filme</b>!<br>
				Eventuell vorgenommene Eintragungen, bzw. Einstellungen im Suchrequester
				werden dabei wieder auf die Voreinstellung zur&uuml;ckgesetzt.
				</dd>
				<dt><br><big><b>0-9</b></big></dt>
				<dd>
				<b>Auflistung der Filme die nicht mit einem Buchstaben beginnen</b>!<br>
				Eventuell vorgenommene Eintragungen, bzw. Einstellungen im Suchrequester
				werden dabei wieder auf die Voreinstellung zur&uuml;ckgesetzt.
				</dd>
				<dt><br><big><b>A - Z</b></big></dt>
				<dd>
				<b>Auflistung der Filme die mit dem gew&auml;hlten Buchstaben beginnen</b>!<br>
				Eventuell vorgenommene Eintragungen, bzw. Einstellungen im Suchrequester
				werden dabei wieder auf die Voreinstellung zur&uuml;ckgesetzt.
				</dd>
			</dl>
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>