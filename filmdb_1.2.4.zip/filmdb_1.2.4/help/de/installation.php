<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td nowrap>
		<h1 id="print"><b>Installation</b></h1>
	</td></tr>
	<tr><td class="txt">
		<h2><b>Die Installation unterteilt sich in zwei Abschnitte:</b></h2><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" class="txt">
			Nach dem entpacken des Archives "<b>install_AJAX-<wbr>FilmDB_1.2.X.zip</b>"
			bekommen Sie folgende Dateien zu Gesicht...<br><br>
			<b>Bevor Sie mit der Installation beginnen:</b><br><br>
			Lesen Sie das PDF und die README-Datei aufmerksam durch!<br>
			</td><td valign="top">
				<img src="help/images/install/archive.png" alt="Zip" style="margin-left: 1em;" width="213" height="176" border="0">
			</td></tr>
		</table>
		</p><br><p>
		Zuerst kommt das Kopieren auf den <b>Webserver</b>...<br><br>
		Dazu wird der Installer "<code>install.php</code>" und das Archiv 
		"<code>filmdb_1.2.X.zip</code>" <b>via FTP in das Wurzelverzeichnis</b>
		Ihrer Domain <b>hoch</b>ge<b>laden</b>! Um den letzten Schritt einzuleiten sollten
		Sie nun die <b>URL</b> "<code>http://www.ihr-domain-name.de/install.php</code>" 
		im Browser <b>aufrufen</b>...
		</p><p>
		...dann folgt die automatisierte <b>Installation</b>...
		<small><br><br>Dieser skript stammt urspr&uuml;nglich vom "<b>Txt-Db-API</b>" Paket und wurde<br>von dem Autor <b>Mario Sansone</b> freundlicherweise zur Verf&uuml;gung gestellt!</small>
		<br><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_0.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_de_1.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_de_2.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		Falls <b>keine Schreibberechtigung</b> vorliegt...<br>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_fehler.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		...ansonsten geht's <b>HIER</b> weiter!<br>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_de_3.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_de_4.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_de_5.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_de_6.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_de_7.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		Am Ende sollten Sie aus Sicherheits<wbr>gr&uuml;nden die Datei <b>install.php</b>
		via FTP <b>l&ouml;schen</b> und im Browser die <b>URL</b> "<code>http://www.ihr-domain-name.de/filmdb/</code>"
		<b>aufrufen</b>. Die Installation ist nun abgeschlossen.
		<br><br>
		Um der lieben Sicherheit willen melden Sie sich danach als "<code>admin</code>" mit 
		dem Passwort "<code>admin</code>" an und &auml;ndern sofort das Passwort indem Sie 
		im Einstellungs-<wbr>Requester auf den Knopf <b>BenutzerListe</b> klicken! 
		<br><br>
		Viel Spass...
		</p><br><br><p>
		<b>P.S.</b> Falls bei der Installation die Preparation der <b>MySQL-Datenbank</b> aus
		irgendwelchen Gr&uuml;nden nicht geklappt haben sollte, kann Diese auch manuell 
		durchgef&uuml;hrt werden <i>(z.B. via phpMyAdmin)</i>!
		<br><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/mysql_de_1.png" alt="phpMySQL" style="margin-right: 1em;" width="480" height="330" border="0">
			</td><td valign="top" class="txt">
			Erstellung der <b>MySQL-<wbr>Datenbank</b>
			<i>(z.B. via phpMySQL)</i>.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/mysql_de_2.png" alt="phpMySQL" style="margin-right: 1em;" width="480" height="330" border="0">
			</td><td valign="top" class="txt">
			Erzeugung der <b>MySQL-<wbr>Tabellen</b>
			durch import der Datei "install/<wbr>db_defs.sql"
			<i>(z.B. via phpMySQL)</i>.
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>