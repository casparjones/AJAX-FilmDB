<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="3" nowrap>
			<h1 id="print"><b>Konditionen</b></h1>
			<h2><b>Browser Voraussetzungen</b></h2>
		</td>
	</tr><tr>
		<td width="32" align="center" valign="top" class="txt">
			<img src="images/sign/ajax.png" alt="AJAX" width="32" height="32" border="0">
		</td>
		<td width="20">&nbsp;&nbsp;&nbsp;</td>
		<td class="txt">
			<big><b>XMLHTTPRequest-Objekt</b></big> Unterst&uuml;tzung ist die Basis.
		</td>
	</tr><tr>
		<td align="center" valign="top" class="txt">
			<img src="images/sign/javascript.png" alt="JS" width="32" height="32" border="0">
		</td>
		<td width="20">&nbsp;&nbsp;&nbsp;</td>
		<td class="txt">
			<big><b>Javascript 1.5</b></big> Unterst&uuml;tzung ist eine Grundvoraussetzung.
		</td>
	</tr><tr>
		<td align="center" valign="top" class="txt">
			<img src="images/sign/css.png" alt="CSS" width="32" height="32" border="0">
		</td>
		<td width="20">&nbsp;&nbsp;&nbsp;</td>
		<td class="txt">
			<big><b>CSS 2.1</b></big> Unterst&uuml;tzung ist eine Grundvoraussetzung.<br>
			<small>Ber&uuml;cksichtigung des <b>z-index</b> von <b>IFrames</b> ist eine Grundvoraussetzung.</small>
		</td>
	</tr><tr>
		<td align="center" valign="top" class="txt">
			<img src="images/sign/html.png" alt="HTML" width="32" height="32" border="0">
		</td>
		<td width="20">&nbsp;&nbsp;&nbsp;</td>
		<td class="txt">
			<big><b>HTML 4.x</b></big> Unterst&uuml;tzung ist eine Grundvoraussetzung.
			<br><small>800 x 600 Pixel Fenstergr&ouml;&szlig;e ist die Mindestanforderung!</small>
		</td>
	</tr><tr>
		<td align="center" valign="top" class="txt">
		
		</td>
		<td width="20">&nbsp;&nbsp;&nbsp;</td>
		<td class="txt">
			<br><img src="help/images/browser/seamonkey.png" title="SeaMonkey" alt="seamonkey" width="32" height="32" border="0">
			<img src="help/images/browser/mozilla.png" title="Mozilla" alt="mozilla" width="32" height="32" border="0">
			<img src="help/images/browser/firefox.png" title="Firefox" alt="firefox" width="32" height="32" border="0">
			<img src="help/images/browser/netscape.png" title="Netscape" alt="netscape" width="32" height="32" border="0">
			<img src="help/images/browser/kmeleon.png" title="K-Meleon" alt="kmeleon" width="32" height="32" border="0">
			<img src="help/images/browser/epiphany.png" title="Epiphany" alt="epiphany" width="32" height="32" border="0">
			<img src="help/images/browser/camino.png" title="Camino" alt="camino" width="32" height="32" border="0">
			<img src="help/images/browser/safari.png" title="Safari" alt="safari" width="32" height="32" border="0">
			<img src="help/images/browser/konqueror.png" title="Konqueror" alt="konqueror" width="32" height="32" border="0">
			<img src="help/images/browser/opera.png" title="Opera 9" alt="opera" width="32" height="32" border="0">
			<br><small>...diese Browser erf&uuml;llen aktuell (fast) alle Voraussetzungen durch ihre
			<br>Gecko oder KHTML/WebKit/Opera basierenden Rendering Engines!</small>
		</td>
	</tr><tr>
		<td colspan="3" nowrap><br></td>
	</tr><tr>
		<td colspan="3" nowrap><h2><b>Server Voraussetzungen</b></h2></td>
	</tr><tr>
		<td width="32" align="center" valign="top" class="txt">
			<img src="images/sign/php.png" alt="PHP" width="32" height="32" border="0">
		</td>
		<td width="20">&nbsp;&nbsp;&nbsp;</td>
		<td class="txt">
			<big><b>PHP 4.3.x</b></big> Unterst&uuml;tzung ist eine Grundvoraussetzung.<br>
			<small>Die Einstellung der <b>magic quotes</b> muss auf <b>Off</b> stehen <i>(auch GPC)</i>.</small>
		</td>
	</tr><tr>
		<td align="center" valign="top" class="txt">
			<img src="images/sign/mysql.png" alt="MySQL" width="32" height="32" border="0">
		</td>
		<td width="20">&nbsp;&nbsp;&nbsp;</td>
		<td class="txt">
			<big><b>MySQL 4.x</b></big> Unterst&uuml;tzung ist eine Grundvoraussetzung.
		</td>
	</tr>
</table>
<br>
