<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<h2><b>Administration</b></h2><br>
		Wenn Sie als <b>Administrator</b> angemeldet sind, haben Sie hier umfangreiche M&ouml;glichkeiten
		um auf dem <b>Server</b> bestimmte <b>Prozeduren</b> auszuf&uuml;hren.
		<br><br>
	</td></tr>
	<tr><td>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/admin_req.png" alt="Einstellungen" style="margin-right: 1em;" width="444" height="564" border="0">
			</td><td width="30" height="24" valign="top">
				<img src="help/images/button/prefs_on.png" alt="Prefs" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Einstellungen</b></big>
			</td></tr>
			<tr><td colspan="3" valign="top" class="txt"><br>
			<big><b>*Der angemeldete Administrator verzweigt nach einem Klick auf den obigen Knopf zu diesem Requester</b></big>.
			<br><br>
			Die ersten vier <b>Bearbeitungen</b> werden unter <b>Bedienung/Kn&ouml;pfe</b> abgehandelt!
			<br><br>
			Ob und welche nachfolgenden Prozeduren angezeigt werden, h&auml;ngt stark von Ihrem Provider ab.
			<br><br>
			"<b>save_mode=off</b>" ist eine generelle Grundvoraussetzung.<br>
			"<b>ZLib Support=enabled</b>" ist eine Grundvoraussetzung f&uuml;r die Sicherungsdateien und die Wiederherstellung.
			<br><br>
			*<small>Der Administrator hat zus&auml;tzlich, umfangreiche M&ouml;glichkeiten.
			Wie weit seine Rechte gehen sollen, kann in "<b>config/<wbr>config.php</b>" definiert werden!</small>
			</td></tr>
		</table>
		<br><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/copy_blobs.png" alt="copy_blobs" style="margin-right: 1em;" width="350" height="286" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Kopiere alle Poster von der Datenbank auf den Server</b>!</big>
			<br><br>
			W&auml;hrend dieser <b>Prozedur</b> bekommen Sie immer den <i>Aktionsindikator</i><br>
			<img src="help/de/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>zu sehen, unabh&auml;ngig davon ob Sie unter <b>"Bearbeite die Grundkonfiguration"</b> 
			<b>"Fortschrittsanzeige benutzen"</b> ausgew&auml;hlt haben!
			<br><br>
			<small>Bei Bedarf, werden alle Aktionen dieser Operation in die Logdatei geschrieben.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/copy_poster.png" alt="copy_poster" style="margin-right: 1em;" width="350" height="286" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Kopiere alle Poster vom Server in die Datenbank</b>!</big>
			<br><br>
			W&auml;hrend dieser <b>Prozedur</b> bekommen Sie immer den <i>Aktionsindikator</i><br>
			<img src="help/de/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>zu sehen, unabh&auml;ngig davon ob Sie unter <b>"Bearbeite die Grundkonfiguration"</b> 
			<b>"Fortschrittsanzeige benutzen"</b> ausgew&auml;hlt haben!
			<br><br>
			<small>Bei Bedarf, werden alle Aktionen dieser Operation in die Logdatei geschrieben.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/extract_blobs.png" alt="extract_blobs" style="margin-right: 1em;" width="350" height="286" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Extrahiere alle Poster aus der Datenbank und speichere sie auf dem Server</b>!</big>
			<br><br>
			Ob Sie w&auml;hrend dieser <b>Prozedur</b> einen <i>Progressindikator</i><br>
			<img src="help/de/images/progess_ind.png" align="center" alt="progess" width="202" height="18" border="0">
			<br>oder einen <i>Aktionsindikator</i><br>
			<img src="help/de/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>zu sehen bekommen, h&auml;ngt davon ab ob Sie unter <b>"Bearbeite die Grundkonfiguration"</b> 
			<b>"Fortschrittsanzeige benutzen"</b> ausgew&auml;hlt haben, oder nicht!
			<br><br>
			<small>Bei Bedarf, werden alle Aktionen dieser Operation in die Logdatei geschrieben.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/extract_poster.png" alt="extract_poster" style="margin-right: 1em;" width="350" height="286" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Extrahiere alle Poster vom Server und speichere sie in der Datenbank</b>!</big>
			<br><br>
			Ob Sie w&auml;hrend dieser <b>Prozedur</b> einen <i>Progressindikator</i><br>
			<img src="help/de/images/progess_ind.png" align="center" alt="progess" width="202" height="18" border="0">
			<br>oder einen <i>Aktionsindikator</i><br>
			<img src="help/de/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>zu sehen bekommen, h&auml;ngt davon ab ob Sie unter <b>"Bearbeite die Grundkonfiguration"</b> 
			<b>"Fortschrittsanzeige benutzen"</b> ausgew&auml;hlt haben, oder nicht!
			<br><br>
			<small>Bei Bedarf, werden alle Aktionen dieser Operation in die Logdatei geschrieben.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/clear_blobs.png" alt="clear_blobs" style="margin-right: 1em;" width="350" height="272" border="0">
			</td><td valign="top" class="txt">	
			<big><b><strong>Leere</strong> alle Poster in der Datenbank</b>!</big>
			<br><br>
			Ob Sie w&auml;hrend dieser <b>Prozedur</b> einen <i>Progressindikator</i><br>
			<img src="help/de/images/progess_ind.png" align="center" alt="progess" width="202" height="18" border="0">
			<br>oder einen <i>Aktionsindikator</i><br>
			<img src="help/de/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>zu sehen bekommen, h&auml;ngt davon ab ob Sie unter <b>"Bearbeite die Grundkonfiguration"</b> 
			<b>"Fortschrittsanzeige benutzen"</b> ausgew&auml;hlt haben, oder nicht!
			<br><br>
			<small>Bei Bedarf, werden alle Aktionen dieser Operation in die Logdatei geschrieben.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/delete_poster.png" alt="delete_poster" style="margin-right: 1em;" width="350" height="272" border="0">
			</td><td valign="top" class="txt">	
			<big><b><strong>L&ouml;sche</strong> alle Poster auf dem Server</b>!</big>
			<br><br>
			Ob Sie w&auml;hrend dieser <b>Prozedur</b> einen <i>Progressindikator</i><br>
			<img src="help/de/images/progess_ind.png" align="center" alt="progess" width="202" height="18" border="0">
			<br>oder einen <i>Aktionsindikator</i><br>
			<img src="help/de/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>zu sehen bekommen, h&auml;ngt davon ab ob Sie unter <b>"Bearbeite die Grundkonfiguration"</b> 
			<b>"Fortschrittsanzeige benutzen"</b> ausgew&auml;hlt haben, oder nicht!
			<br><br>
			<small>Bei Bedarf, werden alle Aktionen dieser Operation in die Logdatei geschrieben.</small>
			</td></tr>
		</table>
		<br><br>		
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/backup_dbase.png" alt="backup_dbase" style="margin-right: 1em;" width="418" height="281" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Sicherungsdatei der Datenbank als ZIP-Archiv speichern</b>!</big>
			<br><br>
			Wenn Sie auf den Knopf <span class="button">Starten</span> klicken, wird der 
			Requester geschlossen und es beginnt ein regul&auml;rer Download.
			<br><br>
			<small>Die Einstellung der maximalen Gr&ouml;&szlig;e einer heraufladbaren Datei
			<i>(<b>upload_<wbr>max_<wbr>filesize</b>)</i> ist erst dann von fundamentaler Bedeutung, 
			wenn dieses Archiv zwecks Wiederherstellung wieder heraufgeladen werden soll.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/backup_poster.png" alt="backup_poster" style="margin-right: 1em;" width="422" height="281" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Sicherungsdatei aller Posterdateien als ZIP-Archiv speichern</b>!</big>
			<br><br>
			Wenn Sie auf den Knopf <span class="button">Starten</span> klicken, wird der 
			Requester geschlossen und das Archiv wird heruntergeladen.
			<br><br>
			Die Einstellung der maximalen Gr&ouml;&szlig;e einer heraufladbaren Datei
			<i>(<b>upload_<wbr>max_<wbr>filesize</b>)</i> bestimmt, ob die Poster auf mehrere 
			<b>ZIP-<wbr>Archive</b> verteilt werden m&uuml;ssen.
			Falls dem so ist, kommt <b>der nachfolgende Requester</b> zum Einsatz!
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/backup_list.png" alt="backup_list" style="margin-right: 1em;" width="444" height="286" border="0">
			</td><td valign="top" class="txt">	
			Die runterzuladenden <b>Poster wurden auf mehrere ZIP-<wbr>Archive verteilt</b>, weil Ihr Zugang nur eine begrenzte Dateigr&ouml;&szlig;e zul&auml;&szlig;t!
			<br><br>
			Klicken Sie die Listeneintr&auml;ge an um die Archive Herunterzuladen.
			Warten Sie jeweils solange, bis das Archiv vollst&auml;ndig heruntergeladen wurde,
			bevor Sie den n&auml;chsten Listeneintrag anklicken.
			<br><br>
			Wenn Sie alle Listeneintr&auml;ge abgearbeitet haben, klicken Sie auf den Knopf 
			<span class="button">OK</span> um den Requester zu schlie&szlig;en.
			<br><br>			
			<small></small>
			</td></tr>
		</table>		
		<br><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/select_dbase.png" alt="select_dbase" style="margin-right: 1em;" width="404" height="233" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Sicherungsdatei der Datenbank laden</b>!</big>
			<br><br>
			Wenn Sie auf den Knopf <span class="button">Raufladen</span> klicken,  
			wird der Requester einen <i>Aktionsindikator</i> anzeigen<br>
			<img src="help/de/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>w&auml;hrend das Archiv heraufgeladen wird.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/askfor_dbase.png" alt="askfor_dbase" style="margin-right: 1em;" width="404" height="233" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Nachdem das ZIP-<wbr>Archiv heraufgeladen wurde 
			erscheint dieser Requester</b>.</big>
			<br><br>
			Wenn Sie auf den Knopf <span class="button">Wiederherstellen</span> klicken,  
			wird der nachfolgende Requester angezeigt.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/restore_dbase.png" alt="restore_dbase" style="margin-right: 1em;" width="350" height="286" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Wiederherstellung der Datenbank mittels Sicherungsdatei</b>!</big>
			<br><br>
			W&auml;hrend dieser <b>Prozedur</b> bekommen Sie immer den <i>Aktionsindikator</i><br>
			<img src="help/de/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>zu sehen, unabh&auml;ngig davon ob Sie unter <b>"Bearbeite die Grundkonfiguration"</b> 
			<b>"Fortschrittsanzeige benutzen"</b> ausgew&auml;hlt haben!
			<br><br>
			<small>Bei Bedarf, werden alle Aktionen dieser Operation in die Logdatei geschrieben.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/select_poster.png" alt="select_poster" style="margin-right: 1em;" width="404" height="233" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Sicherungsdatei der Poster laden</b>!</big>
			<br><br>
			Wenn Sie auf den Knopf <span class="button">Raufladen</span> klicken,  
			wird der Requester einen <i>Aktionsindikator</i> anzeigen<br>
			<img src="help/de/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>w&auml;hrend das Archiv heraufgeladen wird.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/askfor_poster.png" alt="askfor_poster" style="margin-right: 1em;" width="404" height="233" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Nachdem das ZIP-<wbr>Archiv heraufgeladen wurde 
			erscheint dieser Requester</b>.</big>
			<br><br>
			Wenn Sie auf den Knopf <span class="button">Wiederherstellen</span> klicken,  
			wird der nachfolgende Requester angezeigt.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/restore_poster.png" alt="restore_poster" style="margin-right: 1em;" width="350" height="286" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Wiederherstellung der Posterdateien mittels Sicherungsdatei</b>!</big>
			<br><br>
			W&auml;hrend dieser <b>Prozedur</b> bekommen Sie immer den <i>Aktionsindikator</i><br>
			<img src="help/de/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>zu sehen, unabh&auml;ngig davon ob Sie unter <b>"Bearbeite die Grundkonfiguration"</b> 
			<b>"Fortschrittsanzeige benutzen"</b> ausgew&auml;hlt haben!
			<br><br>
			<small>Bei Bedarf, werden alle Aktionen dieser Operation in die Logdatei geschrieben.</small>
			</td></tr>
		</table>
		<br><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/log_req.png" alt="log_req" style="margin-right: 1em;" width="422" height="357" border="0">
			</td><td valign="top" class="txt">	
			<big>Wenn Sie im <b>Einstellungs-<wbr>Requester</b> den Knopf
			<span class="button">Logdatei&nbsp;Anzeigen</span> angeklickt haben,
			gelangen Sie hierhin.</big>			
			<br><br>
			Jede Prozedur f&auml;ngt mit dem <b class="green">LOG:</b>-Datum und dem <b class="green">CMD:</b>-Befehl an!
			<br><br>
			<b class="blue">WARNING:</b> beschreibt eine <b>Warnung</b>, die keine Konsequenzen hat!
			<br><br> 
			<b class="red">ERROR:</b> beschreibt einen <b>Fehler</b>, der aus dem Text hervorgeht!
			<br><br>
			Bei Bedarf, kann die <b>Logdatei</b> durch einen Klick auf <span class="button">Leeren</span> <b>geleert</b> werden.
			</td></tr>
		</table>
	</td></tr>
</table>
<br>