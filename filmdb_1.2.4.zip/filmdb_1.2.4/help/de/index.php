<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/filmdb.png" alt="FilmDB" style="margin: 1em 1em 0 1em;" width="64" height="64" border="0">
			</td><td valign="bottom">
			<span style="font-size:72px; font-weight:bold; line-height:72px; color:#ccc;">Dokumentation</span>
			</td></tr>
			<tr><td colspan="2" valign="top"><br>
		<dl style="margin-left:56px;">
		<dd>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='Einf&uuml;hrung';parent.window.ajaxhelp('help/de/introduction.php','page');">Einf&uuml;hrung</a></h1>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='Konditionen';parent.window.ajaxhelp('help/de/conditions.php','page');">Konditionen</a></h1>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='Installation';parent.window.ajaxhelp('help/de/installation.php','page');">Installation</a></h1>
			<h1 id="item">Bedienung:</h1>
			<dl><dd>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Bedienung / Ansicht';parent.window.ajaxhelp('help/de/views.php','page');">Verschiedene Datenansichten</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Bedienung / Infos';parent.window.ajaxhelp('help/de/infos.php','page');">Verschiedene Informationen</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Bedienung / Display';parent.window.ajaxhelp('help/de/display.php','page');">Verschiedene Displaytexte</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Bedienung / Kn&ouml;pfe';parent.window.ajaxhelp('help/de/buttons.php','page');">Verschiedene Funktionskn&ouml;pfe</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Bedienung / Filter';parent.window.ajaxhelp('help/de/filter.php','page');">Verschiedene Sortierungen</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Bedienung / Anzeige';parent.window.ajaxhelp('help/de/navigate.php','page');">Navigation und Anzeige</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Bedienung / Suche';parent.window.ajaxhelp('help/de/search.php','page');">Datenbank-Suche</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Bedienung / Auswahl';parent.window.ajaxhelp('help/de/selection.php','page');">Fixe Vorauswahlen</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Bedienung / Bearbeiten';parent.window.ajaxhelp('help/de/edit.php','page');">Filme bearbeiten</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Bedienung / Admin';parent.window.ajaxhelp('help/de/admin.php','page');">Administration</a></h2>
			</dd></dl>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='Probleme';parent.window.ajaxhelp('help/de/problems.php','page');">Probleme</a></h1>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='Copyrights';parent.window.ajaxhelp('help/en/copyright.php','page');">Copyrights</a></h1>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='Lizens';parent.window.ajaxhelp('help/en/license.php','page');">Lizens</a></h1>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='API(s)';parent.window.ajaxhelp('help/de/api.php','page');">API(s)</a></h1>
		</dd></dl>
			</td></tr>
		</table>
	</td></tr>
</table>
<br>