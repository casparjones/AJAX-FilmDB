<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Bedienung</b></h1>
		<img src="help/de/images/handling.png" alt="Handling" width="540" height="400" border="0">
	</td></tr>
</table>
<br>