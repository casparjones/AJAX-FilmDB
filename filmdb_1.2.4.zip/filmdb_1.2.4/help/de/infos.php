<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<h2><b>Verschiedene Informationen</b></h2><br>
		Wenn Sie in der oberen <b>Bedienungsleiste</b> eine der beiden <b>Grafiken anklicken</b>,
		bekommen Sie die nachfolgenden Informationen angezeigt:
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td width="20">
				<img src="help/images/ajax.png" alt="A.J.A.X." width="20" height="20" border="0">
			</td><td class="txt" nowrap>
				&nbsp;<big><b>AJAX</b>-Implementation und Betriebsvoraussetzungen</big>
			</td></tr><td colspan="2">
				<img src="help/de/images/ajax_req.png" alt="AJAX" width="533" height="403" border="0">
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td width="180">
				<img src="help/de/images/logo_de.png" alt="FilmDatenBank" width="180" height="20" align="middle" border="0">
			</td><td class="txt" nowrap>
				&nbsp;<big><b>Copyright</b>-Informationen</big>
			</td></tr><td colspan="2">
				<img src="help/de/images/about_req.png" alt="Copyright" width="539" height="406" border="0">
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>