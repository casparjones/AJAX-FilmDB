<?php
	$thesize = filesize('../FilmDB_Dokumentation.pdf');
	$thesize /= 1024; $pdfsize = ($thesize/1024 >= 1)?round(($thesize/1024),2).' MByte':round($thesize,0).' KByte';
?>
<table width="88%" height="100%" border="0" cellpadding="0" cellspacing="0">
	<tr><td height="100%" align="center" valign="middle" class="txt" nowrap>
		<br><span style="font-size:32px; font-weight:bold; line-height:32px; color:#ccc;">Diese Dokumentation als:&nbsp;</span><a target="_blank" type="application/octet-stream" title="PDF: <?= $pdfsize ?>" href="help/FilmDB_Dokumentation.pdf"><img src="help/images/pdf.png" alt="PDF" width="32" height="32" border="0"></a>
		<br><br>
		<img src="help/images/logo.png" alt="FilmDB" width="256" height="256" border="0">
	</td></tr>
</table>
