<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<h2><b>Verschiedene Displaytexte</b></h2><br>
		In der oberen <b>Bedienungsleiste</b> existiert ein kleines <b>Display</b>,
		welches verschiedene Programmzust&auml;nde anzeigt:<br><br><br>
		<div class="display" align="center" nowrap>
			Version&nbsp;<b>1.0.0</b>&nbsp;&bull;&nbsp;01-M&auml;r-2006
		</div>&nbsp;&nbsp;<big><b>Sie sind nicht angemeldet</b>!</big><br clear="all">
		<small><br>Sie d&uuml;rfen alle <b>Filme sichten und ausdrucken</b>, sowie eine <b>eigene Programmeinstellung speichern</b>.</small><br>
		<br><br>
		<div class="display" align="center" nowrap>
			Benutzerkennung:&nbsp;<b>youcan</b>
		</div>&nbsp;&nbsp;<big><b>Sie sind als Benutzer angemeldet</b>!</big><br clear="all">
		<small><br>Sie d&uuml;rfen zus&auml;tzlich <b>Filme hinzuf&uuml;gen, bearbeiten und l&ouml;schen</b>, sowie die <b>Liste der Entleiher bearbeiten</b>.</small><br>
		<br><br>
		<div class="display" align="center" nowrap>
			Benutzerkennung:&nbsp;<b>admin</b>
		</div>&nbsp;&nbsp;<big><b>Sie sind als Administrator angemeldet</b>!</big><br clear="all">
		<small><br>Sie d&uuml;rfen zus&auml;tzlich die <b>Grundeinstellung bearbeiten</b>, sowie die <b>Liste der Benutzer bearbeiten</b>.</small><br>
		<br><br>
		<div class="display" align="center" nowrap>
			Benutzermodus:&nbsp;<b>Hilfe</b>
		</div>&nbsp;&nbsp;<big><b><strong>HIER</strong> sind Sie zur Zeit</b>!</big><br clear="all">
		<br><br>
		<div class="display" align="center" nowrap>
			Benutzermodus:&nbsp;<b>Hinzuf&uuml;gen</b>
		</div>&nbsp;&nbsp;<big><b>Sie sind angemeldet</b>!</big><br clear="all">
		<br><br>
		<div class="display" align="center" nowrap>
			Benutzermodus:&nbsp;<b>Bearbeiten</b>
		</div>&nbsp;&nbsp;<big><b>Sie sind angemeldet</b>!</big><br clear="all">
	</td></tr>
</table>
<br>