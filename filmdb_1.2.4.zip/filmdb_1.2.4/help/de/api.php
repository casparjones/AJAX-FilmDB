<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>API(s)</b></h1>
	</td></tr>
	<tr><td class="txt">
		<dl><dt><nobr><big><b>Export</b></big></nobr></dt>
			<dd>Um von anderen Programmen aus auf die Datenbank zugreifen
			zu k&ouml;nnen, wurde ein <b>simples API</b> erstellt, dass sowohl
			via <b>GET</b> als auch via <b>POST</b> erreichbar ist und nach 
			erfolgreichem Aufruf einen wohlgeformten und validen <b>XML-Strom</b>
			oder eine <b>XML-Datei</b> zur&uuml;ckgibt.
			<br><small><br></small>
			<b>Syntax</b>:<ul>
				<li>path: <code> export.php</code></li>
				<li>query: <code> ?imdb_id= </code><small>([0-9]{7})</small><br>
				<span style="color:green;">Original ID der Internet Movie Database</span>
				<br><i>...oder...</i><br>
				query: <code> ?file_id= </code><small>([0-9]{*})</small><br>
				<span style="color:green;">Original ID der MySQL Datenbank</span></li>
				<li>subquery: <code> &amp;stream= </code><small>(true|false)</small><br>
				<span style="color:green;">Gibt einen Stream oder eine Datei zur&uuml;ck</span>
				<br><i>...optional...</i><br></li>
				<li>subsubquery: <code> &amp;dtd= </code><small>(internal|external)</small><br>
				<span style="color:green;">Dokument Typen Deklaration intern oder extern referenziert, oder ohne DTD</span></li>
			</ul><small><br></small>
			<b>Errorcodes</b>:<ul>
				<li><code>error: no movie id</code></li>
				<li><code>error: unknown movie id</code></li>
			</ul>
		</dd></dl>
	</td></tr>
</table>
<br>