<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Probleme</b></h1>
	</td></tr>
	<tr><td class="txt">
<dl><dt><nobr><big><b>Gecko Engine</b></big></nobr></dt>
<dd>Bei Firefox und Konsorten kommt es zu einem <b style="color:green;">Darstellungsfehler in den Requestern</b>:<ul>
<li>Der Prompt in den  "<code>input</code>"-Objekten wird nicht mehr angezeigt.</li>
</ul></dd></dl>

<dl><dt><nobr><big><b>KHTML/WebKit Engine</b></big></nobr></dt>
<dd>Bei Safari und Konsorten kommt es zu einem <b style="color:green;">Darstellungsfehler in den Requestern</b>:<ul>
<li>Die Regeln f&uuml;r Gitternetzlinien "<code>rules</code>" in Tabellen
werden nicht interpretiert.</li>
<li>Das CSS-Attribut <code>border-radius</code> wird noch nicht untert&uuml;tzt.</li>
</ul></dd></dl>

<dl><dt><nobr><big><b>Internet Explorer</b></big></nobr></dt>
<dd>Im Prinzip bleibt die <b>Funktionalit&auml;t erhalten</b>, aber 
die <b style="color:green;">Darstellung litt</b> unter den typischen CSS-Schw&auml;chen des Browsers:<ul>
<li>Der <code>z-index</code> der <b>select</b>-Objekte wird nicht ber&uuml;cksichtigt.</li>
<li>Die <b>Alpha-Maske</b> von 32 Bit PNG's wird nicht ber&uuml;cksichtigt. (<b style="color:green;">fixiert</b>)</li>
<li>Das CSS-Attribut <code>position: fixed</code> wird noch nicht untert&uuml;tzt (<b style="color:green;">fixiert</b>)</li>
<li>Das CSS-Attribut <code>height:100%</code> wird fehlinterpretiert (<b style="color:green;">fixiert</b>)</li>
<li>Das CSS-Attribut <code>border-radius</code> wird noch nicht untert&uuml;tzt.</li>
</ul></dd></dl>

<dl><dt><nobr><big><b>Opera 9</b></big></nobr></dt>
<dd>Die Darstellung ist nahezu perfekt. Nur minimale <b style="color:green;">Darstellungsfehler in den Requestern</b>.
</dd></dl>

<dl><dt><nobr><big><b>Opera<sup>*</sup></b></big> (&lt; <b>9</b>)</nobr></dt>
<dd>Leider ist das Programm durch die CSS-Schw&auml;chen des Browsers <b style="color:red;">unbedienbar</b>:<ul>
<li>Der <code>z-index</code> des <b>IFrame</b>s wird nicht ber&uuml;cksichtigt,<br>
wodurch alle Requester hinter dem IFrame verschwinden.</li>
</ul></dd></dl>

<dl><dt><nobr><big><b>PHP</b></big></nobr></dt>
<dd>Mit aktivierten "<code>magic-quotes</code>" kommt es zu <b style="color:red;">Fehlinterpretationen</b>.
Unter Apache l&auml;&szlig;t sich das Problem durch eine "<code>.htaccess</code>"-Datei
im Programmordner beheben:<ul>
<li><code>php_flag magic_quotes_gpc off</code></li>
<li><code>php_flag magic_quotes_runtime off</code></li>
<li><code>php_flag magic_qoutes off</code></li>
</ul></dd></dl>

<dl><dt><nobr><big><b>*</b></big></nobr></dt>
<dd><small>Alle Browser mit Darstellungsproblemen k&ouml;nnen einfach direkt die Seite des 
<b>IFrame</b>s "<b>list.php</b>" aufrufen, und so zumindest alle Filme in
der Listenansicht zu Gesicht bekommen. <b>PDA</b>'s und <b>Mobiltelefone</b> rufen den Ordner 
"<b>mobile/</b>" und <b>RSS-Reader</b> den Ordner "<b>rss/</b>" auf!
</small></dd></dl>
	</td></tr>
</table>
<br>