<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<h2><b>Verschiedene Sortierungen</b></h2><br>
		Wenn Sie im <b>IFrame</b> die obere <b>Funktionsleiste</b> bedienen,
		stehen Ihnen nachfolgenden M&ouml;glichkeiten zur Verf&uuml;gung:<br>
		<span class="tooltype"><small>Die aktuelle Sortierung ist jeweils BLAU hinterlegt.</small></span>
		<br>
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<img src="help/de/images/filter_left.png" alt="Filter" width="400" height="20" border="0">
			</td></tr><td class="txt">
			<dl>
				<dt><big><b>?</b></big></dt>
				<dd>
				<b>Sortiert</b> die Spalte <b>ausschlie&szlig;lich absteigend nach</b> 
				der <b>Verf&uuml;gbarkeit</b> der Filme.
				</dd>
				<dt><br><big><b>!</b></big></dt>
				<dd>
				<b>Sortiert</b> die Spalte <b>ausschlie&szlig;lich aufsteigend nach</b> 
				der <b>IMDb-Wertung</b> <i>(0-100)</i>.
				</dd>
				<dt><br><big><b>ID</b></big></dt>
				<dd>
				<b>Sortiert</b> die Spalte <b>aufsteigend und absteigend nach</b> 
				der <b>Identifikations<wbr>nummer</b> der Filme.
				</dd>
				<dt><br><big><b>Titel (deutscher)</b> <i>(original)</i></big> &nbsp;<img src="help/images/button/desc_on.png" alt="Desc" width="12" height="14" border="0"></dt>
				<dd>
				<b>Sortiert</b> die Spalte <b>aufsteigend und absteigend</b> 
				sowohl nach dem <b>deutschen Titel</b>, als auch nach dem 
				<b>Originaltitel</b> der Filme.
				</dd>
				<dt><br><big><b style="color:darkgrey;">Regie</b></big></dt>
				<dd>
				Diese Spalte kann <b>nicht sortiert</b> werden!
				</dd>
			</dl>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<img src="help/de/images/filter_right.png" alt="Filter" width="400" height="20" border="0">
			</td></tr><td class="txt">
			<dl>
				<dt><big><b style="color:darkgrey;">Land</b></big></dt>
				<dd>
				Diese Spalte kann <b>nicht sortiert</b> werden!
				</dd>
				<dt><br><big><b>Jahr</b></big></dt>
				<dd>
				<b>Sortiert</b> die Spalte <b>aufsteigend und absteigend nach</b> 
				dem <b>Produktions<wbr>jahr</b> der Filme.
				</dd>
				<dt><br><big><b>Dauer</b></big></dt>
				<dd>
				<b>Sortiert</b> die Spalte <b>aufsteigend und absteigend nach</b> 
				der <b>Spiel<wbr>dauer</b> der Filme.
				</dd>
				<dt><br><big><b>Medium</b></big></dt>
				<dd>
				<b>Sortiert</b> die Spalte <b>aufsteigend und absteigend nach</b> 
				der <b>Art des Mediums</b> der Filme.
				</dd>
				<dt><br><big><b>Datum</b></big></dt>
				<dd>
				<b>Sortiert</b> die Spalte <b>aufsteigend und absteigend nach</b> 
				dem <b>Datum der Eintragung</b> der Filme.
				</dd>
				<dt><br><big><b>Poster/*</b></big></dt>
				<dd>
				<b>Sortiert</b> die Spalte <b>ausschlie&szlig;lich absteigend nach</b> 
				der <b>Verf&uuml;gbarkeit</b> der Poster.
				</dd>
			</dl>
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>