<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Einf&uuml;hrung</b></h1>
		<h2><b>Intention</b></h2><br>
	</td></tr><tr><td class="txt">
		<p>
		Auf der Suche nach einer Filmdatenbank, die meinen pers&ouml;nlichen Bed&uuml;rfnissen
		gerecht werden sollte, stie&szlig; ich auf das Programm <b>php4flicks</b> von David Fuchs.
		Es kam meinen Vorstellungen von einer Filmdatenbank am n&auml;chsten.
		</p><p>
		Da mir das Layout nicht gefiel und die in Fenster ausgelagert Funktionalit&auml;t 
		&uuml;berhaupt nicht mein Ding sind, kam ich auf den Gedanken die Fenster durch
		<b>Requester</b> <i>(modale Dialoge)</i> zu ersetzen.
		</p><p>
		Ich nahm mir vor, ein <b>AJAX-Programm</b> zu schreiben, dass sich wie eine <b>Mac OS-X
		Applikation</b> verh&auml;lt und auch so aussieht. Selbstverst&auml;ndlich multilingual,
		mit skalierbarer GUI und benutzerspezifischen Einstellungsm&ouml;glichkeiten.
		</p><p>
		Das <b>FilmDB</b> nicht umbedingt Windoof-IE freundlich programmiert wurde sollte
		nach dem obigen Absatz niemanden verwundern. Ich bin kein Fan der Produkte aus dem
		Hause "KleinstWeich" und sehe keinen Anlass Diese im Besonderen zu unterst&uuml;tzen.
		Nach einer Vielzahl von Anfragen habe ich mich aber doch noch dazu &uuml;berreden lassen,
		die wichtigsten Anpassungen f&uuml;r IE 5.5 und 6 vorzunehmen.
		</p><p>
		Mir kam es bei der Programmierung ganz besonders auf eine hohe Vertr&auml;glichkeit 
		mit der <b>Gecko</b>- und der <b>KHTML/WebKit</b>-Engine an. Das Opera in den Versionen
		kleiner 9 dabei durch das Raster fallen w&uuml;rde war zwar keine Absicht, lie&szlig;  
		sich aber nicht vermeiden. <i>(Mehr zu diesem Thema unter <b>Probleme</b>)</i>
		</p>
	</td></tr>
	<tr><td>
		<h2><b>Farbschemata</b></h2><br>
	</td></tr><tr><td class="txt">
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<div class="colbox" style="background-color:#bdcaac;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Dunkelgr&uuml;n</b></big><br>
				Diese Farbe deklariert immer einen Informationsbereich.
			</td></tr>
			<tr><td>
				<div class="colbox" style="background-color:#dee3cb;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Hellgr&uuml;n</b></big><br>
				Diese Farbe deklariert immer einen Bearbeitungsbereich.
			</td></tr>
			<tr><td>
				<div class="colbox" style="background-color:#ffe3db;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Rosa/Pink</b></big><br>
				Diese Farbe deklariert immer einen Bereich erh&ouml;hter Aufmerksamkeit,<br> 
				sowie den Status der deaktivierten Markierung f&uuml;r verliehene Filme!
			</td></tr>
			<tr><td>
				<div class="colbox" style="background-color:#9dcfff;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Blau</b></big><br>
				Diese Farbe deklariert immer einen Funktions- bzw. Anzeigebereich.
			</td></tr>
			<tr><td>
				<div class="colbox" style="background-color:#ff867f;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Rot</b></big><br>
				Diese Farbe deklariert den Status der aktivierten Markierung f&uuml;r verliehene Filme!
			</td></tr>
			<tr><td>
				<div class="colbox" style="background-color:#97d599;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Gr&uuml;n</b></big><br>
				Diese Farbe deklariert den Status der aktivierten Markierung f&uuml;r verf&uuml;gbare Filme!
			</td></tr>
		</table>
		</p>
	</td></tr>
	<tr><td>
		<h2><b>Funktionsschemata</b></h2><br>
	</td></tr><tr><td class="txt">
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<img style="margin: 0 1em 1em 0;" src="help/images/noposter.gif" alt="Poster" width="32" border="0">
			</td><td valign="top" class="txt">
				<big><b>Film-Poster</b></big><br>
				Ein Klick auf ein Poster wird immer die <b>IMDb-Seite des 
				benannten Filmes</b> <i>(in einer neuen Browserinstanz)</i> 
				<b>&ouml;ffnen</b>.
			</td></tr>
			<tr><td></td><td valign="top" class="txt">
				<big><b>Tooltips</b></big> <span class="tooltype">Tooltips</span><br>
				Hinter jedem <b>Objekt</b> das einen <b>Tooltip</b> besitzt, und/oder das
				sich <b style="color:#336699;">BLAU</b> verf&auml;rbt beim &uuml;berfahren 
				mit der Maus, verbirgt sich eine <b>Funktion</b>.
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>