<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<h2><b>Filme bearbeiten / hinzuf&uuml;gen</b></h2><br>
		Wenn Sie als Benutzer angemeldet sind, k&ouml;nnen Sie durch einen <b>Klick auf</b> diesen
			<table style="display:inline;" border="0" cellpadding="0" cellspacing="0"><tr><td valign="top" width="14" height="14">
				<img src="help/images/edit_off.png" title="Film bearbeiten" alt="Edit" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Film&nbsp;bearbeiten</span>
			</td></tr></table>
			oder diesen <span class="button">Bearbeiten</span> <b>Knopf</b>
			den ausgew&auml;hlten <b>Film bearbeiten</b>.<br><br>
		<p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/addedit_req.png" alt="Bearbeiten" style="margin-right: 1em;" width="400" height="289" border="0">
			</td><td valign="top" class="txt">
			Die <b>Bearbeitung</b> eines Filmes ist in <b>9 Themen<wbr>bl&ouml;cke</b> unterteilt.
			<br><br>
			Die Darstellung ist <i>(&auml;hnlich wie bei der <b>Poster<wbr>ansicht</b>)</i> selbstumbrechend,
			wodurch der verf&uuml;gbare Platz immer optimal ausgenutzt wird.
			</td></tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/media_area.png" alt="Media" style="margin-right: 1em;" width="218" height="177" border="0">
			</td><td valign="top" class="txt">
			Der erste <b>Themenblock</b> ist der Einzige, den Sie gewissenhaft <b>ausf&uuml;llen</b> sollten.
			Alle anderen Daten wurden schon automatisch ermittelt <i>(Ausnahme: <b>deutscher Titel</b>)</i>.
			<br><br>
			<b>W&auml;hlen</b> Sie ein <b>Medium</b> aus und das Programm wird alle zusammenh&auml;ngenden
			Einstellungen selbstst&auml;ndig mit sinnvollen Werten vorbelegen. Ohne ausgew&auml;hlte
			<b>Sprache</b> l&auml;&szlig;t sich der Film nicht in der Datenbank abspeichern!
			<br><br>
			Nachfolgend das <b>Spektrum</b> der <b>Popup-<wbr>Requester</b> mit allen verf&uuml;gbaren Einstellungswerten!
			</td><td valign="top">
				<img title="Art des Mediums" src="help/images/reqs/media_req.png" alt="Media" style="margin-left: 1em;" width="81" height="162" border="0">
			</tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="bottom" nowrap>
				<img title="Medientyp" src="help/images/reqs/type_req.png" alt="Type" style="margin-right: 0.25em;" width="58" height="107" border="0">
				<img title="Containerformat" src="help/images/reqs/cont_req.png" alt="Container" style="margin-right: 0.25em;" width="71" height="107" border="0">
				<img title="Video-Codec" src="help/images/reqs/vcodec_req.png" alt="Video-Codec" style="margin-right: 0.25em;" width="71" height="118" border="0">
				<img title="Signalformat" src="help/images/reqs/format_req.png" alt="Format" style="margin-right: 0.25em;" width="59" height="129" border="0">
				<img title="Aspekt Ratio" src="help/images/reqs/aspect_req.png" alt="Aspect-Ratio" style="margin-right: 0.25em;" width="82" height="74" border="0">
				<img title="Audio-Codec" src="help/images/reqs/acodec_req.png" alt="Audio-Codec" style="margin-right: 0.25em;" width="66" height="118" border="0">
				<img title="Kanalzahl" src="help/images/reqs/channel_req.png" alt="Channel" style="margin-right: 0.25em;" width="47" height="129" border="0">
				<img title="Frequenz" src="help/images/reqs/freq_req.png" alt="Frequencies" width="53" height="74" border="0">
			</tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/title_area.png" alt="Title" style="margin-right: 1em;" width="224" height="177" border="0">
			</td><td valign="top" class="txt">
			Im zweiten <b>Themenblock</b> muss nur noch der <b>deutsche Titel</b> eingetragen
			werden, da diese Information momentan noch nicht automatisch ermittelt werden kann.
			<br><br>
			Standardm&auml;&szlig;ig steht hier immer eine Kopie des <b>Originaltitels</b>.
			Ohne einen <b>deutschen Titel</b> l&auml;&szlig;t sich der Film nicht in der Datenbank abspeichern!
			<br><br>
			<small>Wenn Ihnen der <b>deutsche Titel</b> des Filmes nicht bekannt ist,
			k&ouml;nnen Sie Diesen einfach mittels nachfolgender Eingabe in eine
			<b>Suchmaschine</b> ermitteln:<br><br></small>
			<strong>film "XXXXXX" deutscher titel</strong>
			<small><br><br>Wobei XXXXXX f&uuml;r den Ihnen schon
			bekannten <b>Titel</b> steht.</small>
			</td></tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/info_area.png" alt="Infos" style="margin-right: 1em;" width="224" height="169" border="0">
			</td><td valign="top" class="txt">
			Im sechsten <b>Themenblock</b> kann noch direkt der Eintrag <b>Verliehen</b> belegt
			werden. Das Datum wird dabei auf den aktuellen Tag gesetzt. Sie m&uuml;ssen nur noch den
			Entleiher bestimmen.
			<br><br>
			Standardm&auml;&szlig;ig wird das Datum in umgekehrter Reihenfolge genutzt.
			Zuerst das <b>Jahr</b>, dann der <b>Monat</b> und am Ende der <b>Tag</b>.
			Als <b>Trennzeichen</b> fungiert das Minuszeichen.
			<br><br>
			<small>Als <b>angemeldeter Benutzer</b> k&ouml;nnen Sie jederzeit die
			<b>Liste der Entleiher</b> bearbeiten und um eventuell fehlende, oder neue Namen
			erg&auml;nzen.</small>
			</td></tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/poster_url_req.png" alt="Bearbeiten" style="margin-right: 1em;" width="416" height="221" border="0">
			</td><td valign="top" class="txt">
			Dieser <b>Requester</b> erscheint, wenn Sie auf den nachfolgenden <b>Knopf im Posterbereich</b> klicken.
			<br><br>
			<table style="display:inline;" border="0" cellpadding="0" cellspacing="0"><tr><td valign="top">
				<img src="help/images/poster/url.png" title="Raufladen" alt="Edit" width="32" height="32" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Raufladen</span>
			</td></tr></table>
			<br><br>
			Hiermit kann man dem Film ein anderes <b>Poster</b> zuordnen.
			</td></tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/poster_file_req.png" alt="Bearbeiten" style="margin-right: 1em;" width="404" height="222" border="0">
			</td><td valign="top" class="txt">
			Dieser <b>Requester</b> erscheint, wenn Sie auf den nachfolgenden <b>Knopf im Posterbereich</b> klicken.
			<br><br>
			<table style="display:inline;" border="0" cellpadding="0" cellspacing="0"><tr><td valign="top">
				<img src="help/images/poster/upload.png" title="Raufladen" alt="Edit" width="32" height="32" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Raufladen</span>
			</td></tr></table>
			<br><br>
			Hiermit kann man dem Film ein anderes <b>Poster</b> zuordnen.
			</td></tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/poster_clear_req.png" alt="Bearbeiten" style="margin-right: 1em;" width="326" height="186" border="0">
			</td><td valign="top" class="txt">
			Dieser <b>Requester</b> erscheint, wenn Sie auf den nachfolgenden <b>Knopf im Posterbereich</b> klicken.
			<br><br>
			<table style="display:inline;" border="0" cellpadding="0" cellspacing="0"><tr><td valign="top">
				<img src="help/images/poster/clear.png" title="Leeren" alt="Edit" width="32" height="32" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Leeren</span>
			</td></tr></table>
			<br><br>
			Hiermit kann man dem Film ein <b>Dummy-Poster</b> zuordnen. 
			Das <b>Original-Poster</b> wird dabei gel&ouml;scht <i>(Blob und/oder Datei)</i>!
			</td></tr>
		</table>
		</p><br><p>		
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/people_req.png" alt="Bearbeiten" style="margin-right: 1em;" width="437" height="382" border="0">
			</td><td valign="top" class="txt">
			Dieser <b>Requester</b> erscheint, wenn Sie den <b>Namen</b> einer Person 
			&auml;ndern und mehrere Personen mit diesem Namen existieren, oder wenn kein
			passender Eintrag gefunden wurde.
				<br><br>
				Die gefundenen Personen werden nach Relevanz sortiert angezeigt.
				<br><br>
				Mittels der auf der rechten Seite jeder Zeile sichtbaren <b>IMDb</b>-<wbr>Grafik,
				k&ouml;nnen Sie <i>(z.B. f&uuml;r Kontroll<wbr>zwecke)</i> die <b>IMDb</b>-<wbr>Seite der benannten
				Person <i>(in einer neuen Browser<wbr>instanz)</i> &ouml;ffnen.
				<br><br>
				<b>W&auml;hlen</b> Sie eine Person durch <b>Anklicken</b> aus!
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/exportask_req.png" alt="Exportieren" style="margin-right: 1em;" width="400" height="318" border="0">
			</td><td valign="top" class="txt">
			<big>Wenn Sie im 'Benutzermodus: <b>Bearbeiten</b>' 
			den Knopf <span class="button">Exportieren</span> angeklickt haben, 
			<b>gelangen Sie hierhin</b>.</big>
			<br><br>
			W&auml;hlen Sie aus, ob beim Export eine <b>DTD</b>
			mitgeliefert werden soll. Wenn ja, welche!
			<br><br>
			Soll die <b>DTD</b> in jede <b>XML-Datei</b> inkludiert
			werden <em>(Intern)</em>, oder soll nur in einer Zeile
			darauf verwiesen werden <em>(Extern)</em>?
			<br><br>
			Ohne <b>DTD</b> ist das Dokument zwar wohlgeformt 
			<em>(reicht f&uuml;r den im/export in FilmDB aus)</em>, 
			aber nicht valide. 
			<br><br>
			<small><b>DTD</b> = Document Type Description</small>
			</td></tr>
		</table>
		<br>	
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/rescanask_req.png" alt="Erneuern" style="margin-right: 1em;" width="400" height="251" border="0">
			</td><td valign="top" class="txt">
			<big>Wenn Sie im 'Benutzermodus: <b>Bearbeiten</b>' 
			den Knopf <span class="button">Erneuern</span> angeklickt haben, 
			<b>gelangen Sie hierhin</b>.</big>
			</td></tr>
		</table>
		<br>	
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/deleteask_req.png" alt="L&ouml;schen" style="margin-right: 1em;" width="400" height="251" border="0">
			</td><td valign="top" class="txt">
			<big>Wenn Sie im 'Benutzermodus: <b>Bearbeiten</b>' 
			den Knopf <span class="button">L&ouml;schen</span> angeklickt haben, 
			<b>gelangen Sie hierhin</b>.</big>
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>