<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<h2><b>Navigation und Anzeige</b></h2><br>
		Wenn Sie im <b>IFrame</b> die untere, fixe <b>Funktionsleiste</b> bedienen,
		stehen Ihnen im linken Bereich nachfolgenden M&ouml;glichkeiten zur Verf&uuml;gung:<br><br>
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<img src="help/de/images/navig_area.png" alt="Navig" width="160" height="20" border="0">
			</td></tr><td class="txt">
			<dl>
				<dt><img src="help/images/button/first_on.png" alt="First" width="10" height="10" border="0"></dt>
				<dd>
				Springt zum <b>Anfang</b> der pro Seite sichtbaren/verf&uuml;gbaren Filme.
				</dd>
				<dt><br><img src="help/images/button/prev_on.png" alt="Previous" width="10" height="10" border="0"></dt>
				<dd>
				Springt um die Anzahl der pro Seite sichtbaren Filme <b>r&uuml;ckw&auml;rts</b>, die in den
				<b>Programm-<wbr>Einstellungen</b> vom Besucher/Benutzer eingestellt wurde.
				</dd>
				<dt><br><img src="help/images/button/next_on.png" alt="Next" width="10" height="10" border="0"></dt>
				<dd>
				Springt um die Anzahl der pro Seite sichtbaren Filme <b>vorw&auml;rts</b>, die in den
				<b>Programm-<wbr>Einstellungen</b> vom Besucher/Benutzer eingestellt wurde.
				</dd>
				<dt><br><img src="help/images/button/last_on.png" alt="Last" width="10" height="10" border="0"></dt>
				<dd>
				Springt zum <b>Ende</b> der pro Seite sichtbaren/verf&uuml;gbaren Filme.
				</dd>
				<dt><br><b>33-48</b> von <b>294</b></dt>
				<dd>
				<b>Numerische Anzeige der aktuellen Auflistung der Filme</b>!<br>
				<b>n-n</b> zeigt die Auswahl der momentan sichtbaren Filme an,
				und <b>von n</b> die absolute Anzahl der Filme.<br>
				Die Anzahl der pro Seite sichtbaren Filme kann in den <b>Programm-<wbr>
				Einstellungen</b> von jedem Besucher individuell vorgenommen werden.
				</dd>
			</dl>
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>