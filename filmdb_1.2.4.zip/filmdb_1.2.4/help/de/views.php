<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<h2><b>Verschiedene Datenansichten</b></h2><br>
		Wenn Sie in der oberen <b>Bedienungsleiste</b> eine der vier <b>Ansichtsgrafiken anklicken</b>,
		bekommen Sie die nachfolgenden Datenansichten angezeigt:<br><br>
		<p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/list_view.png" alt="Listenansicht" style="margin-right: 1em;" width="400" height="232" border="0">
			</td><td valign="top" width="26" height="24">
				<img src="help/images/button/list_on.png" alt="List" width="26" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Listenansicht</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Diese <b>Ansicht</b> zeigt eine mittlere Informations<wbr>dichte
			an, um m&ouml;glichst viele <b>Filme</b> pro Seite unterzubringen.
			<br><br>
			Wenn Sie als Benutzer angemeldet sind, k&ouml;nnen Sie durch einen <b>Klick auf</b> diesen <b>Knopf</b>...
			<br><br>
			<table border="0" cellpadding="0" cellspacing="0"><tr><td valign="top" width="14" height="14">
				<img src="help/images/edit_off.png" title="Film bearbeiten" alt="Edit" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Film&nbsp;bearbeiten</span>
			</td></tr></table>
			<br>
			...den <b>ausgew&auml;hlten Film bearbeiten</b>.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/lent_req.png" alt="Filmstatus" style="margin-right: 1em;" width="310" height="283" border="0">
			</td><td valign="top" class="txt">
			Wenn Sie als Benutzer angemeldet sind, k&ouml;nnen Sie durch einen <b>Klick auf</b> 
			einen dieser beiden <b>Kn&ouml;pfe</b>...
			<br><br>
			<table border="0" cellpadding="0" cellspacing="0"><tr><td valign="top" width="14" height="14">
				<img src="help/images/avail_is.png" title="Film verf&uuml;gbar" alt="Avail" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Verf&uuml;gbar</span>
			</td></tr><tr><td colspan="2" height="4"></td></tr><tr><td valign="top" width="14" height="14">
				<img src="help/images/avail_no.png" title="Film verliehen" alt="Avail" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Verliehen an XXXX am 01-Jan-2005</span>
			</td></tr></table>
			<br>
			...den <b>Verleihstatus des ausgew&auml;hlten Filmes bearbeiten</b>.
			<br><br>
			<big>Dieser <b>Requester</b> dient dazu, den <b>Filmstatus</b> an die aktuelle 
			Situation anzupassen!</big>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" class="txt">
			Wenn Sie mit der <b>Maus &uuml;ber</b> die <b>Miniaturposter</b> am rechten Rand 
			der Anzeige fahren, erscheint ein <b>Tooltip mit</b> dem dazugeh&ouml;rigen 
			<b>Poster</b> in Originalgr&ouml;&szlig;e!
			<br><br>
			Wenn Sie eines der <b>Miniaturposter</b> anklicken, wird die IMDb-Seite 
			des benannten Filmes <i>(in einer neuen Browserinstanz)</i> ge&ouml;ffnet.
			<br><br>
			<big><b>Die Tooltips erscheinen nur, wenn Sie unter Einstellungen:
			"Ohne Poster in der Listenansicht!" abgeschaltet haben.</b></big>
			<br><br>
			Ansonsten werden statt der <b>Miniaturposter</b> nur einfache <b>Verweisgrafiken</b>
			angezeigt...
			<br><br>
			<table border="0" cellpadding="0" cellspacing="0"><tr><td valign="top" width="14" height="14">
				<img src="help/images/link.png" title="IMDb-Seite" alt="IMDb" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Zeige die IMDb-Seite des Filmes an</span>
			</td></tr></table>
			</td><td valign="top">
				<img src="help/de/images/tooltip.png" alt="Tooltip" style="margin-left: 1em;" width="105" height="179" border="0">
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/poster_view.png" alt="Posteransicht" style="margin-right: 1em;" width="400" height="232" border="0">
			</td><td valign="top" width="26" height="24">
				<img src="help/images/button/poster_on.png" alt="Poster" width="26" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Posteransicht</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Diese <b>Ansicht</b> konzentriert sich ganz auf die <b>Filmposter</b> und zeigt 
			sonst nur noch den deutschen Titel an.
			<br><br>
			Wenn Sie als Benutzer angemeldet sind, k&ouml;nnen Sie durch einen <b>Klick auf</b> diesen <b>Knopf</b>...
			<br><br>
			<table border="0" cellpadding="0" cellspacing="0"><tr><td valign="top" width="14" height="14">
				<img src="help/images/edit_off.png" title="Film bearbeiten" alt="Edit" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Film&nbsp;bearbeiten</span>
			</td></tr></table>
			<br>
			...den <b>ausgew&auml;hlten Film bearbeiten</b>.
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/row_view.png" alt="Reihenansicht" style="margin-right: 1em;" width="400" height="232" border="0">
			</td><td valign="top" width="26" height="24">
				<img src="help/images/button/row_on.png" alt="Row" width="26" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Reihenansicht</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Diese <b>Ansicht</b> zeigt mehrere <b>Filme</b> pro Seite an.
			Hier ist genug Platz um alle relevanten Informationen aufzulisten.
			<br><br>
			Wenn Sie als Benutzer angemeldet sind, k&ouml;nnen Sie durch einen <b>Klick auf</b> diesen <b>Knopf</b>...
			<br><br>
			<span class="button">Bearbeiten</span>
			<br><br>
			...den <b>ausgew&auml;hlten Film bearbeiten</b>.
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/film_view.png" alt="Filmansicht" style="margin-right: 1em;" width="400" height="232" border="0">
			</td><td valign="top" width="25" height="24">
				<img src="help/images/button/film_on.png" alt="Film" width="25" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Filmansicht</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Diese <b>Ansicht</b> zeigt immer nur einen <b>Film</b> pro Seite an.
			Hier ist genug Platz um alle gespeicherten Informationen
			auf einen Blick zug&auml;nglich zu machen.
			<br><br>
			Wenn Sie als Benutzer angemeldet sind, k&ouml;nnen Sie durch einen <b>Klick auf</b> diesen <b>Knopf</b>...
			<br><br>
			<span class="button">Bearbeiten</span>
			<br><br>
			...den <b>ausgew&auml;hlten Film bearbeiten</b>.
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/list_php.png" alt="Listenansicht" style="margin-right: 1em;" width="366" height="172" border="0">
			</td><td>&nbsp;</td><td valign="top" class="txt">
				<big><b>Inkompatible Browser</b></big><br><br>
			Diese <b>Ansicht</b> ist nur f&uuml;r inkompatible oder alte Browser gedacht <i>(JavaScript muss aktiviert sein)</i>.
			So lassen sich zumindest die wichtigsten Informationen noch sichten.
			<br><br>
			Diese <b>Ansicht</b> erreichen Sie &uuml;ber die <b>URL</b>...
			<br><br>
			<img src="help/images/list_url.png" alt="URL" width="200" height="16" border="0">
			<br><br>
			...<b>localhost</b> sollten Sie durch Ihre Domain ersetzen!
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/images/mobile.png" alt="Handyansicht" style="margin-right: 1em;" width="170" height="442" border="0">
			</td><td>&nbsp;</td><td valign="top" class="txt">
				<big><b>PDA und Handy</b></big><br><br>
			Diese <b>Ansicht</b> ist nur f&uuml;r HTML-f&auml;hige Mobil-Telefone und PDA's gedacht.
			So lassen sich zumindest die wichtigsten Informationen noch sichten <i>(sortiert nach Eingansdatum)</i>.
			<br><br>
			Diese <b>Ansicht</b> erreichen Sie &uuml;ber die <b>URL</b>...
			<br><br>
			<img src="help/images/mobile_url.png" alt="URL" width="204" height="16" border="0">
			<br><br>
			...<b>localhost</b> sollten Sie durch Ihre Domain ersetzen!
			</td><td>&nbsp;</td><td valign="top" rowspan="2">
				<img src="help/de/images/rss.png" alt="Rssansicht" style="margin-left: 1em;" width="199" height="440" border="0">
			</td></tr><tr><td>&nbsp;</td><td align="right" valign="bottom" class="txt">
				<big><b>RSS Feed</b></big><br><br>
			Diese <b>Ansicht</b> ist nur f&uuml;r RSS-f&auml;hige Programme gedacht.
			So lassen sich immer die 10 neuesten Filme sichten.
			<br><br>
			Diese <b>Ansicht</b> erreichen Sie &uuml;ber die <b>URL</b>...
			<br><br>
			<img src="help/images/rss_url.png" alt="URL" width="180" height="16" border="0">
			<br><br>
			...<b>localhost</b> sollten Sie durch Ihre Domain ersetzen und bei <b>http:</b> darf auch <b>feed:</b> stehen!
			<td>&nbsp;</td></td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>