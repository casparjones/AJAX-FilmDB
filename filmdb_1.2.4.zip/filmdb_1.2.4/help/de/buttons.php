<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<h2><b>Verschiedene Funktionskn&ouml;pfe</b></h2><br>
		Wenn Sie in der oberen <b>Bedienungsleiste</b> einen der rechts liegenden <b>Kn&ouml;pfe anklicken</b>,
		bekommen Sie Zugriff auf nachfolgende Funktionen:<br><br>
		<p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/add_req.png" alt="Film hinzuf&uuml;gen" style="margin-right: 1em;" width="346" height="219" border="0">
			</td><td width="30" height="24" valign="top">
				<img src="help/images/button/plus_on.png" alt="Add" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Film hinzuf&uuml;gen</b>*</big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Geben Sie den <b>Originaltitel</b> des Filmes ein, den Sie der Datenbank
			hinzuf&uuml;gen m&ouml;chten und klicken Sie auf <b>Suchen</b>!
			<br><br>
			<small>Wenn Ihnen der <b>Originaltitel</b> des Filmes nicht bekannt ist,
			k&ouml;nnen Sie Diesen einfach mittels nachfolgender Eingabe in eine
			<b>Suchmaschine</b> ermitteln:<br><br></small>
			<strong>film "XXXXXX" original titel</strong>
			<small><br><br>Wobei XXXXXX f&uuml;r den Ihnen schon
			bekannten <b>Titel</b> steht.</small>
			<br><br>
			*<small>Nur angemeldete Benutzer.<small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/movie_req.png" alt="Film ausw&auml;hlen" style="margin-right: 1em;" width="438" height="382" border="0">
			</td><td valign="top" class="txt">
				Wenn dieser Requester erscheint, ist der Suchvorgang auf <b>IMDb</b> <i>(Internet Movie Database)</i> abgeschlossen.
				<br><br>
				Die gefundenen Filme werden nach Priorit&auml;t sortiert angezeigt.
				Somit ist der oberste Film auch meist der Richtige.
				<br><br>
				Mittels der auf der rechten Seite jeder Zeile sichtbaren <b>IMDb</b>-<wbr>Grafik,
				k&ouml;nnen Sie <i>(z.B. f&uuml;r Kontroll<wbr>zwecke)</i> die <b>IMDb</b>-<wbr>Seite des benannten
				Filmes <i>(in einer neuen Browser<wbr>instanz)</i> &ouml;ffnen.
				<br><br>
				<b>W&auml;hlen</b> Sie einen Film durch <b>Anklicken</b> aus!
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/import_req.png" alt="Film importieren" style="margin-right: 1em;" width="404" height="222" border="0">
			</td><td width="30" height="24" valign="top">
				<img src="help/images/button/import_on.png" alt="Import" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Film importieren</b>*</big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			W&auml;hlen Sie die <b>XML-Datei</b> des Filmes aus, den Sie der Datenbank
			hinzuf&uuml;gen m&ouml;chten und klicken Sie auf <b>Importieren</b>!
			<br><br>
			*<small>Nur angemeldete Benutzer.<small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/importask_req.png" alt="Film importieren" style="margin-right: 1em;" width="400" height="291" border="0">
			</td><td valign="top" class="txt">
				Wenn dieser Requester erscheint, ist der Importvorgang verifiziert.
				<br><br>
				Falls der ermittelte Film schon in der Datenbank vorhanden ist,
				wird Ihnen das in <b style="color:red;">ROT</b> angezeigt.
				<br><br>
				Mittels der <b>IMDb</b>-<wbr>Nummer, k&ouml;nnen Sie
				<i>(z.B. f&uuml;r Kontroll<wbr>zwecke)</i> die <b>IMDb</b>-<wbr>Seite des benannten
				Filmes <i>(in einer neuen Browser<wbr>instanz)</i> &ouml;ffnen.
				<br><br>
				Klicken Sie auf <b>Importieren</b> um den Vorgang abzuschlie&szlig;en!
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/print_req.png" alt="Datenbank ausdrucken" style="margin-right: 1em;" width="421" height="292" border="0">
			</td><td valign="top" width="30" height="24">
				<img src="help/images/button/print_on.png" alt="Print" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Datenbank ausdrucken</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			W&auml;hlen Sie die Ansicht der Daten aus <i>(egal ob Film-, Reihen-, Poster- oder Listenansicht)</i>  und klicken Sie auf <b>Drucken</b> um eine
			neue Browserinstanz <i>(f&uuml;r den Ausdruck)</i> zu generieren!
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/print_win.png" alt="Ausdruck" style="margin-right: 1em;" width="340" height="187" border="0">
			</td><td valign="top" class="txt">
			Der <b>Ausdruck entspricht</b> weitestgehend dem <b>Inhalt des IFrames</b>.
			<br><br>
			Der gr&ouml;&szlig;te Unterschied besteht darin, dass die von Ihnen getroffene Auswahl
			<i>(z.B. nur Filme die mit "A" beginnen, oder nur Filme die das Wort "Liebe" im
			Titel enthalten)</i> komplett auf einer Seite angezeigt wird.
			<br><br>
			W&auml;hlen Sie im Pulldown-Men&uuml; der Browserinstanz <b>Drucken...</b>
			aus, um diese Seite zu Papier zu bringen!
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/statistic_req.png" alt="Datenbank-Statistik" style="margin-right: 1em;" width="358" height="329" border="0">
			</td><td width="30" height="24" valign="top">
				<img src="help/images/button/info_on.png" alt="Info" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Datenbank Statistik</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Dieser <b>Requester</b> gibt Aufschluss &uuml;ber die wichtigsten
			statistischen Informationen des aktuellen <b>Datenbestand</b>es!
			<br><br>
			Besonders die Angabe &uuml;ber den Speicherumfang der Datenbank
			ist f&uuml;r all diejenigen wichtig, dehnen eine <b>Volumen<wbr>begrenzung</b>
			der <b>MySQL-Datenbank</b> von ihrem Provider auferlegt wurde.
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/cookiepref_req.png" alt="Einstellungen" style="margin-right: 1em;" width="383" height="427" border="0">
			</td><td width="30" height="24" valign="top">
				<img src="help/images/button/prefs_on.png" alt="Prefs" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Einstellungen</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Dieser <b>Requester</b> dient dazu, das <b>Programm</b> auf die pers&ouml;nlichen
			Bed&uuml;rfnisse jedes einzelnen Besuchers <b>einzustellen</b>!
			<br><br>
			<big><b>*Nicht angemeldete Besucher verzweigen direkt hierhin</b></big>.
			<br><br>
			Die Speicherung von Programm<wbr>einstellung setzt voraus,
			dass Sie in ihrem Browser die Einstellung zumindest auf...<br><br>
			"<b>Cookies akzeptieren</b>" und<br>
			"<b>nur von der urspr&uuml;nglichen Website</b>"
			<br><br>
			...gesetzt haben.
			<br><br>
			*<small>Sie d&uuml;rfen alle Filme sichten und ausdrucken,
			sowie eine eigene Programmeinstellung speichern.<small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/user_req.png" alt="Einstellungen" style="margin-right: 1em;" width="396" height="237" border="0">
			</td><td valign="top" class="txt">
			<big>Wenn Sie hier den Knopf <span class="button">Programm</span> 
			oder als Administrator den Eintrag
			<small><b>"Bearbeite die Programm<wbr>einstellungen"</b></small>
			anklicken, gelangen Sie zum obigen <b>Requester</b>.</big>
			<br><br>
			<big><b>*Angemeldete Benutzer verzweigen zuerst zu diesem Requester</b></big>.
			<br><br>
			*<small>Benutzer d&uuml;rfen zus&auml;tzlich Filme hinzuf&uuml;gen, bearbeiten 
			und l&ouml;schen, sowie die Liste der Entleiher bearbeiten.<small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/borrower_req.png" alt="Entleiherliste" style="margin-right: 1em;" width="350" height="372" border="0">
			</td><td valign="top" class="txt">
			<big>Wenn Sie im <b>Auswahl-Requester</b> f&uuml;r <b>Einstellungen</b> den Knopf
			<span class="button">Entleiher</span> oder als Administrator den Eintrag
			<small><b>"Bearbeite die Entleiher<wbr>liste"</b></small> angeklickt haben,
			gelangen Sie hierhin.</big>
			<br><br>
			In diesem <b>Requester</b> k&ouml;nnen angemeldete Benutzer die Liste
			der <b>Entleiher</b> um zus&auml;tzliche Personen <b>erweitern</b> oder <b>korregieren</b>, 
			aber <b>nicht entfernen</b>!
			<br><br>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/admin_req.png" alt="Einstellungen" style="margin-right: 1em;" width="444" height="564" border="0">
			</td><td valign="top" class="txt">
			<big><b>*Der Administrator verzweigt zuerst zu diesem Requester</b></big>.
			<br><br>
			Mehr zu diesem Thema unter <b>Bedienung/Admin</b>
			<br><br>
			*<small>Administratoren d&uuml;rfen zus&auml;tzlich die Grundeinstellung,
			sowie die Liste der Benutzer bearbeiten.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/member_req.png" alt="Benutzerliste" style="margin-right: 1em;" width="330" height="372" border="0">
			</td><td valign="top" class="txt">
			<big>Wenn Sie im <b>Auswahl-Requester</b> f&uuml;r <b>Einstellungen</b> den Eintrag
			<small><b>"Bearbeite die Benutzerliste"</b></small> angeklickt haben,
			gelangen Sie hierhin.</big>
			<br><br>
			In diesem <b>Requester</b> kann nur der angemeldete Administrator die Liste
			der <b>Benutzer</b> um zus&auml;tzliche Personen <b>erweitern</b>, <b>korregieren</b>
			oder <b>entfernen</b>!
			<br><br>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/de/images/config_req.png" alt="Konfiguration" style="margin-right: 1em;" width="387" height="434" border="0">
			</td><td valign="top" class="txt">
			<big>Wenn Sie im <b>Auswahl-Requester</b> f&uuml;r <b>Einstellungen</b> den Eintrag
			<small><b>"Bearbeite die Grundkonfiguration"</b></small> angeklickt haben,
			gelangen Sie hierhin.</big>
			<br><br>
			In diesem <b>Requester</b> kann nur der angemeldete Administrator die 
			<b>Grundeinstellung</b> des Programmes vornehmen!
			<br><br>
			Auf diese Grundeinstellung greift jeder Browser zur&uuml;ck,
			der keine Cookies akzeptiert.
			<br><br>
			Falls die Einstellung... 
			<br><br>
			"<b>Die Poster werden in der Datenbank als Bin&auml;rdaten abgespeichert!</b>"
			<br><br>
			...abgew&auml;hlt wurde, werden fortan alle Filmposter als <b>Dateien</b> <i>(Schema: [0-9]{*}.pic)</i>  
			im Verzeichnis "<b>poster/</b>" abgelegt und nichtmehr als <b>Blobs</b> in der DatenBank. 
			<br><br>
			<small>
			FilmDB sucht grunds&auml;tzlich in beiden Quellen nach Postern, sodas ein Mischbetrieb
			problemlos funktioniert. Blobs und Dateien haben beide ihre Vor- und Nachteile.
			Wessen Account nur wenig MySQL-<wbr>Speicher zur Verf&uuml;gung stellt wird auf Dateien umstellen,
			auch wenn dadurch die Backups via phpMyAdmin nur noch unvollst&auml;ndig sind (ohne Poster). 
			</small>
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/login_req.png" alt="Anmelden" style="margin-right: 1em;" width="352" height="221" border="0">
			</td><td valign="top" width="30" height="24">
				<img src="help/images/button/login_on.png" alt="Login" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Anmelden</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Geben Sie ihren <b>Benutzernamen</b> und ihr <b>Passwort</b> ein und klicken Sie auf <b>OK</b>
			um sich als Benutzer oder Administrator anzumelden!
			<br><br>
			<big>Die <b>Passwort<wbr>&uuml;bergabe</b> erfolgt nicht im Klartext,
			sondern immer kodiert mittels...</big>
			<br><br>
			<b>MD5</b> <i>(Message-Digest Algorithm)</i>
			<br><br>
			<small>Wenn die Anmeldung erfolgreich war, wechselt das Schlosssymbol von 
			der Farbe <b style="color:green;">GR&Uuml;N</b> zu <b style="color:red;">ROT</b>.<small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/logout_req.png" alt="Abmelden" style="margin-right: 1em;" width="378" height="226" border="0">
			</td><td valign="top" width="30" height="24">
				<img src="help/images/button/logout_on.png" alt="Logout" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Abmelden</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Sie sind nun <b>abgemeldet</b>!
			<br><br>
			<small>Wenn die Abmeldung erfolgt ist, wechselt das Schlosssymbol von 
			der Farbe <b style="color:red;">ROT</b> wieder zu <b style="color:green;">GR&Uuml;N</b>.<small>
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/de/images/help_mode.png" alt="Hilfe" style="margin-right: 1em;" width="400" height="232" border="0">
			</td><td valign="top" width="24" height="24">
				<img src="help/images/button/help_on.png" alt="Help" width="24" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Online-Hilfe</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			<big><b><strong>HIER</strong> sind Sie zur Zeit</b>!</big>
			<br><br>
			Die Online-Hilfe erl&auml;utert in knappen Worten die wichtigsten Parameter.
			Eine weiter<wbr>gehendere Dokumentation sollte sich aufgrund der selbst<wbr>erkl&auml;renden
			Benutzer<wbr>oberfl&auml;che <i>(Tooltips)</i> eigentlich er&uuml;brigen.
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>