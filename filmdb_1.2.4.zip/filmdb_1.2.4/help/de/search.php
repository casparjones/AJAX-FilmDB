<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<h2><b>Datenbank-Suche</b></h2><br>
		Wenn Sie im <b>IFrame</b> die untere, fixe <b>Funktionsleiste</b> bedienen,
		stehen Ihnen im mittleren Bereich nachfolgenden M&ouml;glichkeiten zur Verf&uuml;gung:<br>
		<span class="tooltype"><small>Die aktuelle Suchauswahl ist BLAU hinterlegt.</small></span>
		<br>
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<img src="help/images/button/search_off.png" alt="Search" width="14" height="14" border="0">
				<img src="help/de/images/search_req.png" alt="Search" width="362" height="68" border="0">
			</td><td rowspan="2">&nbsp;</td><td valign="top" rowspan="2">
				<img src="help/de/images/search_cat.png" alt="Category" width="145" height="424" border="1">
			</td></tr><td valign="top" class="txt">
			<dl>
				<dt><big><b>In diesen Genres...</b></big></dt>
				<dd>
				Sie k&ouml;nnen an dieser Stelle die <b>Genres an- und abschalten bzw. individuell 
				belegen</b>, um die Auswahl der Filme zu beeinflussen.
				</dd>
				<dt><br><big><b>...nach</b></big></dt>
				<dd>
				Mittels Popup-<wbr>Requester w&auml;hlen Sie <b>das Kriterium</b> aus, <b>in dem gesucht
				werden soll</b>. Das Bild am rechten Rand der Seite zeigt alle Suchkriterien 
				gleichzeitig an.
				</dd>
				<dt><br><big><b>mit</b></big></dt>
				<dd>
				An dieser Stelle geben Sie <b>die Zeichenketten oder die Zahlen</b> ein, 
				<b>nach dehnen</b> im vorgegebenen Kriterium <b>gesucht werden soll</b>.
				<br>
				<b>Bei</b> dem Kriterium "<b>Verf&uuml;gbarkeit</b>" geben Sie bitte
				eine <b>1 f&uuml;r Wahr/Ja</b> und eine <b>0 f&uuml;r Unwahr/Nein</b> ein!
				</dd>
				<dt><br><span class="button">Suchen</span></dt>
				<dd>
				Ein Klick auf diesen Knopf <b>start</b>et den <b>Suchvorgang</b>!
				</dd>
			</dl>
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>