<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Problems</b></h1>
	</td></tr>
	<tr><td class="txt">
<dl><dt><nobr><big><b>Gecko Engine</b></big></nobr></dt>
<dd>With Firefox and Co. you get a <b style="color:green;">misrepresentation</b> in the requesters:<ul>
<li>The Prompt in the "<code>input</code>"-objects is missing.</li>
</ul></dd></dl>

<dl><dt><nobr><big><b>KHTML/WebKit Engine</b></big></nobr></dt>
<dd>With Safari and Co. you get a <b style="color:green;">misrepresentation</b> in the requesters:<ul>
<li>The css attribute "<code>border-radius</code>" is not considered.</li>
<li>The table attribute "<code>rules</code>" is not considered.</li>
</ul></dd></dl>

<dl><dt><nobr><big><b>Internet Explorer</b></big></nobr></dt>
<dd>In principle <b>functionality remains</b>, but the <b style="color:green;">representation
was suffering</b> from the CSS weaknesses</b> of the Browser:<ul>
<li>The <code>z-index</code> of <b>select</b>-objects is not considered.</li>
<li>The <b>alpha-maske</b> of 32 Bit PNG's is not considered  (<b style="color:green;">fixed</b>).</li>
<li>The css attribute "<code>position:fixed</code>" is not considered (<b style="color:green;">fixed</b>).</li>
<li>The css attribute "<code>height:100%</code>" is misinterpreted (<b style="color:green;">fixed</b>).</li>
<li>The css attribute "<code>border-radius</code>" is not considered.</li>
</ul></dd></dl>

<dl><dt><nobr><big><b>Opera 9</b></big></nobr></dt>
<dd>This is nearly perfect. Only a minimum of <b style="color:green;">misrepresentation</b> in the requesters.
</dd></dl>

<dl><dt><nobr><big><b>Opera<sup>*</sup></b></big> (&lt; <b>9</b>)</nobr></dt>
<dd>Unfortunately the program is <b style="color:red;">unusable</b> by the CSS weaknesses of the Browser:<ul>
<li>The <code>z-index</code> of the <b>IFrame</b> is not considered whereby
<br>all Requesters disappear behind the IFrame.</li>
</ul></dd></dl>

<dl><dt><nobr><big><b>PHP</b></big></nobr></dt>
<dd>With activated "<code>magic-quotes</code>" it comes to <b style="color:red;">misinterpretations</b>. With Apache
<br>the problem can be repaired by a "<code>.htaccess</code>" file in the program folder:<ul>
<li><code>php_flag magic_quotes_gpc off</code></li>
<li><code>php_flag magic_quotes_runtime off</code></li>
<li><code>php_flag magic_qoutes off</code></li>
</ul></dd></dl>

<dl><dt><nobr><big><b>*</b></big></nobr></dt>
<dd><small>All Browser with representation problems shoul'd call the page of the
<b>IFrame</b> "<i>list.php</i>" simply directly. Thus at least all films in 
the list can be viewed. <b>PDA</b>'s and <b>mobil phones</b> shoul'd call the folder 
"<b>mobile/</b>" and <b>RSS readers</b> the folder "<b>rss/</b>"!</small>
</dd></dl>
	</td></tr>
</table>
<br>