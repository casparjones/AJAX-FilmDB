<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Display</b></h1>
		<h2><b>Different Displays</b></h2>
	</td></tr>
	<tr><td class="txt">
		In the upper <b>operating area</b> there is a thiny <b>display</b>
		viewing different program modes:<br><br><br>
		<div class="display" align="center" nowrap>
			Version&nbsp;<b>1.0.0</b>&nbsp;&bull;&nbsp;01-M&auml;r-2006
		</div>&nbsp;&nbsp;<big><b>You are not logged in</b>!</big><br clear="all">
		<small><br>You may <b>view and print</b> all film-views and store your own <b>user specific configuration</b>.</small><br>
		<br><br>
		<div class="display" align="center" nowrap>
			Benutzerkennung:&nbsp;<b>youcan</b>
		</div>&nbsp;&nbsp;<big><b>You are logged in as a user</b>!</big><br clear="all">
		<small><br>You may <b>add, edit and delete films</b> and <b>edit the list of borrowers</b> additionally.</small><br>
		<br><br>
		<div class="display" align="center" nowrap>
			logged User:&nbsp;<b>admin</b>
		</div>&nbsp;&nbsp;<big><b>You are logged in as the administrator</b>!</big><br clear="all">
		<small><br>You may <b>edit the basic configuration</b> and <b>edit the list of users</b> additionally.</small><br>
		<br><br>
		<div class="display" align="center" nowrap>
			User Mode:&nbsp;<b>HELP</b>
		</div>&nbsp;&nbsp;<big><b>You are <strong>HERE</strong></b>!</big><br clear="all">
		<br><br>
		<div class="display" align="center" nowrap>
			User Mode:&nbsp;<b>ADD</b>
		</div>&nbsp;&nbsp;<big><b>You are logged in</b>!</big><br clear="all">
		<br><br>
		<div class="display" align="center" nowrap>
			User Mode:&nbsp;<b>EDIT</b>
		</div>&nbsp;&nbsp;<big><b>You are logged in</b>!</big><br clear="all">
	</td></tr>
</table>
<br>