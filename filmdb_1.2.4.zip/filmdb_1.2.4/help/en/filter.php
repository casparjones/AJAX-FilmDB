<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Sort</b></h1>
		<h2><b>Different Assortments</b></h2>
	</td></tr>
	<tr><td class="txt">
		The upper left <b>operating area</b> in the <b>IFrame</b> makes
		the following possibilities available:<br>
		<span class="tooltype"><small>The current Assortment has always a BLUE background.</small></span>
		<br>
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<img src="help/en/images/filter_left.png" alt="Filter" width="400" height="20" border="0">
			</td></tr><td class="txt">
			<dl>
				<dt><big><b>?</b></big></dt>
				<dd>
				<b>Sorts</b> the column <b>exclusively</b> descending according to 
				the <b>availability</b> of the films.
				</dd>
				<dt><br><big><b>!</b></big></dt>
				<dd>
				<b>Sorts</b> the column <b>exclusively</b> ascending according to 
				the <b>IMDb rating</b> <i>(0-100)</i>.
				</dd>
				<dt><br><big><b>ID</b></big></dt>
				<dd>
				<b>Sorts</b> the column <b>ascending and descending</b> according to 
				the <b>identification</b> of the films.
				</dd>
				<dt><br><big><b>Title (local)</b> <i>(original)</i></big> &nbsp;<img src="help/images/button/desc_on.png" alt="Desc" width="12" height="14" border="0"></dt>
				<dd>
				<b>Sorts</b> the column <b>ascending and descending</b> both according to the 
				<b>local title</b> and according to the <b>original title</b> of the films.
				</dd>
				<dt><br><big><b style="color:darkgrey;">Director</b></big></dt>
				<dd>
				This column <b>cannot</b> be sorted!
				</dd>
			</dl>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<img src="help/en/images/filter_right.png" alt="Filter" width="400" height="20" border="0">
			</td></tr><td class="txt">
			<dl>
				<dt><big><b style="color:darkgrey;">Country</b></big></dt>
				<dd>
				This column <b>cannot</b> be sorted!
				</dd>
				<dt><br><big><b>Year</b></big></dt>
				<dd>
				<b>Sorts</b> the column <b>ascending and descending</b> according to 
				the <b>year of production</b> of the films.
				</dd>
				<dt><br><big><b>Duration</b></big></dt>
				<dd>
				<b>Sorts</b> the column <b>ascending and descending</b> according to 
				the <b>duration</b> of the films.
				</dd>
				<dt><br><big><b>Medium</b></big></dt>
				<dd>
				<b>Sorts</b> the column <b>ascending and descending</b> according to 
				the <b>kind of medium</b> of the films.
				</dd>
				<dt><br><big><b>Date</b></big></dt>
				<dd>
				<b>Sorts</b> the column <b>ascending and descending</b> according to 
				the <b>date of entry</b> of the films.
				</dd>
				<dt><br><big><b>Poster/*</b></big></dt>
				<dd>
				<b>Sorts</b> the column <b>exclusively</b> descending according to 
				the <b>availability</b> of the posters.
				</dd>
			</dl>
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>