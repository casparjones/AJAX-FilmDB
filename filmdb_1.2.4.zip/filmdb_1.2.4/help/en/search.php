<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Search</b></h1>
		<h2><b>Search Database</b></h2>
	</td></tr>
	<tr><td class="txt">
		The lower centered <b>operating area</b> in the <b>IFrame</b> 
		makes the following possibilities available:<br>
		<span class="tooltype"><small>The current Search has a BLUE background.</small></span>
		<br>
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td nowrap>
				<img src="help/images/button/search_off.png" alt="Search" width="14" height="14" border="0">
				<img src="help/en/images/search_req.png" alt="Search" width="363" height="69" border="0">
			</td><td rowspan="2">&nbsp;</td><td valign="top" rowspan="2">
				<img src="help/en/images/search_cat.png" alt="Category" width="153" height="424" border="1">
			</td></tr><td valign="top" class="txt">
			<dl>
				<dt><big><b>in this Categories...</b></big></dt>
				<dd>
				Here you can <b>switch on and off the categories</b> individually 
				in order to affect the selection of the films.
				</dd>
				<dt><br><big><b>...for</b></big></dt>
				<dd>
				Select <i>(via popup requester)</i> the <b>criterion</b> in which is <b>to be searched</b>. 
				The picture at the right side of the page shows all search criteria at the same time.
				</dd>
				<dt><br><big><b>with</b></big></dt>
				<dd>
				Enter the character strings or the numbers <b>which should be searched 
				for</b> <i>(in the given criterion)</i>.
				<br>
				<b>Enter</b> a <b>1 for true/yes</b> and a <b>0 for false/no</b>
				to the criterion "<b>Availability</b>"!
				</dd>
				<dt><br><span class="button">search</span></dt>
				<dd>
				Click on this button to <b>start</b> the <b>search procedure</b>!
				</dd>
			</dl>
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>