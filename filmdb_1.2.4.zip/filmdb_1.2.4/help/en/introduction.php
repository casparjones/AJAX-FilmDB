<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Introduction</b></h1>
		<h2><b>Intention</b></h2><br>
	</td></tr><tr><td class="txt">
		<p>
		When I searched for a film data base which should answer my personal needs 
		I encountered <b>php4flicks</b> from David Fuchs. 
		This program could match my conceptions of a film data base best.
		</p><p>
		Since the layout and the functionality <i>(paged out in windows)</i> did not 
		please me at all - I thought it could be a good thing to replace the windows 
		by <b>requesters</b>.
		</p><p>
		I planned to write an <b>AJAX program</b> that behaves and also looks like a 
		<b>Mac OS-X application</b>. Of course multilingual, with scalable GUI and user 
		specific configuration possibilities.
		</p><p>
		<b>FilmDB</b> was not programmed to be particularly Windump-IE friendly.
		This should nobody surprise in accordance with the above paragraph.
		I am not a fan of the products of "<b>M</b>idget<b>S</b>quashy"
		and therefore won't supply any special support. But after a lot of
		inquiries I made then the most important adjustments for IE 5.5 and 6.
		</p><p>
		I paid attention with programming especially to get a high compatibility
		with the <b>Gecko</b> and the <b>KHTML/WebKit</b> engine. That Opera 
		(versions before 9) thereby would fail was no intention but however could 
		not be avoided. <i>(More to this topic at <b>Problems</b>)</i>
		</p>
	</td></tr>
	<tr><td>
		<h2><b>Color patterns</b></h2><br>
	</td></tr><tr><td class="txt">
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<div class="colbox" style="background-color:#bdcaac;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Dark Green</b></big><br>
				This color always defines an information area.
			</td></tr>
			<tr><td>
				<div class="colbox" style="background-color:#dee3cb;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Light Green</b></big><br>
				This color always defines an editing area.
			</td></tr>
			<tr><td>
				<div class="colbox" style="background-color:#ffe3db;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Pink</b></big><br>
				This color always defines an area of increased attention<br>
				and movies as unmarked and lent!
			</td></tr>
			<tr><td>
				<div class="colbox" style="background-color:#9dcfff;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Blue</b></big><br>
				This color always defines a function area.
			</td></tr>
			<tr><td>
				<div class="colbox" style="background-color:#ff867f;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Rot</b></big><br>
				This color always defines movies as marked and lent!
			</td></tr>
			<tr><td>
				<div class="colbox" style="background-color:#97d599;"><br></div>
			</td><td valign="top" class="txt">
				<big><b>Gr&uuml;n</b></big><br>
				This color always defines movies as marked and available!
			</td></tr>		
		</table>
		</p>
	</td></tr>
	<tr><td>
		<h2><b>Function patterns</b></h2><br>
	</td></tr><tr><td class="txt">
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<img style="margin: 0 1em 1em 0;" src="help/images/noposter.gif" alt="Poster" width="32" border="0">
			</td><td valign="top" class="txt">
				<big><b>Film-Poster</b></big><br>
				A click on a poster will always open the <b>IMDb page</b> of the selected film 
				<i>(in a new browser window)</i>.
			</td></tr>
			<tr><td></td><td valign="top" class="txt">
				<big><b>Tooltips</b></big> <span class="tooltype">Tooltips</span><br>
				Each <b>object</b> that provides a <b>tooltip</b> and/or change to
				<b style="color:#336699;">BLUE</b> on mouse over hides itself a <b>function</b>.
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>