<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Infos</b></h1>
		<h2><b>Special Informations</b></h2>
	</td></tr>
	<tr><td class="txt">
		If you <b>click</b> in the upper <b>operating area</b> on one of the two <b>graphics</b>
		you will get the following informations:
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td width="20">
				<img src="help/images/ajax.png" alt="A.J.A.X." width="20" height="20" border="0">
			</td><td class="txt" nowrap>
				&nbsp;<big><b>AJAX</b>-Implementation and basic Conditions</big>
			</td></tr><td colspan="2">
				<img src="help/en/images/ajax_req.png" alt="AJAX" width="533" height="403" border="0">
			</td></tr>
		</table>
		</p><p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td width="180">
				<img src="help/en/images/logo_en.png" alt="FilmDataBase" width="180" height="20" align="middle" border="0">
			</td><td class="txt" nowrap>
				&nbsp;<big><b>Copyright</b>-Informations</big>
			</td></tr><td colspan="2">
				<img src="help/en/images/about_req.png" alt="Copyright" width="539" height="406" border="0">
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>