<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/filmdb.png" alt="FilmDB" style="margin: 1em 1em 0 1em;" width="64" height="64" border="0">
			</td><td valign="bottom">
			<span style="font-size:72px; font-weight:bold; line-height:72px; color:#ccc;">Documentation</span>
			</td></tr>
			<tr><td colspan="2" valign="top"><br>
		<dl style="margin-left:56px;">
		<dd>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='Introduction';parent.window.ajaxhelp('help/en/introduction.php','page');">Introduction</a></h1>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='Conditions';parent.window.ajaxhelp('help/en/conditions.php','page');">Conditions</a></h1>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='Installation';parent.window.ajaxhelp('help/en/installation.php','page');">Installation</a></h1>
			<h1 id="item">Handling:</h1>
			<dl><dd>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Handling / Views';parent.window.ajaxhelp('help/en/views.php','page');">Different Views</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Handling / Infos';parent.window.ajaxhelp('help/en/infos.php','page');">Different Informations</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Handling / Display';parent.window.ajaxhelp('help/en/display.php','page');">Different Displays</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Handling / Buttons';parent.window.ajaxhelp('help/en/buttons.php','page');">Different Buttons</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Handling / Filter';parent.window.ajaxhelp('help/en/filter.php','page');">Different Assortments</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Handling / Navigate';parent.window.ajaxhelp('help/en/navigate.php','page');">Navigation and Viewpanel</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Handling / Search';parent.window.ajaxhelp('help/en/search.php','page');">Search Database</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Handling / Select';parent.window.ajaxhelp('help/en/selection.php','page');">Fixed Selections</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Handling / Edit';parent.window.ajaxhelp('help/en/edit.php','page');">Edit Films</a></h2>
				<h2 id="item"><a onClick="show_sub();document.getElementById('titel').innerHTML='Handling / Admin';parent.window.ajaxhelp('help/en/admin.php','page');">Administration</a></h2>
			</dd></dl>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='Problems';parent.window.ajaxhelp('help/en/problems.php','page');">Problems</a></h1>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='Copyrights';parent.window.ajaxhelp('help/en/copyright.php','page');">Copyrights</a></h1>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='License';parent.window.ajaxhelp('help/en/license.php','page');">License</a></h1>
			<h1 id="item"><a onClick="close_sub();document.getElementById('titel').innerHTML='API(s)';parent.window.ajaxhelp('help/en/api.php','page');">API(s)</a></h1>
		</dd></dl>
			</td></tr>
		</table>
	</td></tr>
</table>
<br>