<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Copyrights</b></h1>
	</td></tr>
	<tr><td class="txt">
<nobr><big><b>Copyright (c) 2005-2008 by Christian Effenberger</b>.<span class="mial"></span></nobr><br>
<nobr>FilmDB is distributed under the terms of the GNU GPL.</big></nobr>
<br><br>
<b>FilmDB is based on php4flicks</b> (c) by 2003-2004 David Fuchs.
I've modified and extended the php4flicks code heavily.
<br><br>
<b>IMDB fetch scripts</b> where taken from PowerMovieList.
Copyright (c) 1998-2003 by Niko. All Rights Reserved.
David Fuchs has modified the code and I've extended this fetch code.
<br><br>
<b>zip.lib 2.4</b> where taken from phpMyAdmin.
Copyright (c) 2004 by Eric Mueller and Denis125. All Rights Reserved.
<br><br>
<b>unzip.lib 1.2</b> where taken from phpMyAdmin.
Copyright (c) 2003 by Holger Boskugel. All Rights Reserved.
<br><br>
<b>Javascript tooltip implementation</b> "wz_tooltip.js" 3.38.
Copyright (c) 2002-2005 Walter Zorn. All rights reserved.
<br><br>
<b>Javascript implementation</b> of the XMLHTTPRequest-Object is based on the Informations
at <a target="_blank" title="Apple Developer Connection" href="http://developer.apple.com/internet/webcontent/xmlhttpreq.html">Apple's Developer Connection Site</a>.
<br><br>
<b>Javascript implementation</b> of the RSA Data Security, Inc.
MD5 Message-Digest Algorithm.
Copyright (c) 1996 by Henri Torgemane. All Rights Reserved.
<br><br>
<b>IE5.5+ PNG Alpha Fix</b> v1.0 by Angus Turnbull http://www.twinhelix.com
<br><br>
<b>position:fixed in IE/Win</b> version 1.8 by Andrew Clover
<br><br>
<b>xmlize()</b> is by Hans Anderson, me@hansanderson.com 
<br><br>
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.
<br><br>
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
<a target="_blank" title="receive a copy of the GNU General Public License" href="http://www.gnu.org/copyleft/gpl.html">GNU General Public License</a> for more details.
<br><br>
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
		</td>
	</tr>
</table>
<br>