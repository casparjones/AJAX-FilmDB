<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td nowrap>
		<h1 id="print"><b>Installation</b></h1>
	</td></tr>
	<tr><td class="txt">
		<h2><b>The Installation is splitted into two parts:</b></h2><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" class="txt">
			After unzipping the archive "<b>install_AJAX-FilmDB_1.2.X.zip</b>"
			you'll see this folderlisting...<br><br>
			<b>Before you start to install:</b><br><br>
			Read the PDF and the README file carefully!<br>
			</td><td valign="top">
				<img src="help/images/install/archive.png" alt="Zip" style="margin-left: 1em;" width="213" height="176" border="0">
			</td></tr>
		</table>
		</p><br><p>
		First the copying to the <b>web directory</b>...
		<br><br>
		<b>Copy</b> the files "<code>filmdb_1.2.X.zip</code>" and "<code>install.php</code>"
		to a web accessible directory and point your browser to <b>install.php</b>!
		</p><p>
		...followed by the automated <b>installation</b>...
		<small><br><br>Originally these script is part of the "<b>Txt-Db-API</b>" package, but it<br>
		was made available by the author <b>Mario Sansone</b> - very friendly!</small>
		<br><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_0.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_en_1.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_en_2.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		If you have <b>no write access</b>...<br>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_error.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		...else we will <b>go on</b>!<br>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_en_3.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_en_4.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_en_5.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_en_6.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/install_en_7.png" alt="Installation" width="552" height="382" border="0">
			</td></tr>
		</table>
		<br>
		At last <b>delete</b> the file "install.php" from web directory and point your 
		browser to where you installed <b>AJAX-FilmDB</b>. Installation is finished now.
		<br><br>
		For security reasons login as "<code>admin</code>" with password 
		"<code>admin</code>" and change the password via config requester!
		<br><br>
		Have fun...
		</p><br><br><p>
		<b>P.S.</b> If the preparation of the <b>MySQL database</b> fails for any reason
		during the installation, this can be accomplished also manually
		<i>(e.g. per phpMyAdmin)</i>!
		<br><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/mysql_en_1.png" alt="phpMySQL" style="margin-right: 1em;" width="480" height="330" border="0">
			</td><td valign="top" class="txt">
			Create the <b>MySQL-<wbr>Database</b>
			<i>(e.g. per phpMySQL)</i>.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/images/install/mysql_en_2.png" alt="phpMySQL" style="margin-right: 1em;" width="480" height="330" border="0">
			</td><td valign="top" class="txt">
			Generate the <b>MySQL-<wbr>Tables</b>
			thru importing the file "install/<wbr>db_defs.sql"
			<i>(e.g. per phpMySQL)</i>.
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>