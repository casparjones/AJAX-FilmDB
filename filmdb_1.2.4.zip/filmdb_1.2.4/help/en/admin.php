<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td class="txt">
		<h2><b>Administration</b></h2><br>
		If you are announced as <b>administrator</b> - you get extensive  
		possibilities to determined <b>server procedures</b>.
		<br><br>		
	</td></tr>
	<tr><td>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/admin_req.png" alt="Preferences" style="margin-right: 1em;" width="444" height="503" border="0">
			</td><td width="30" height="24" valign="top">
				<img src="help/images/button/prefs_on.png" alt="Prefs" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Preferences</b></big>
			</td></tr>
			<tr><td colspan="3" valign="top" class="txt"><br>
			<big><b>*The logged administrator links to this Requester after a click on the button above</b></big>.
			<br><br>
			The first four <b>list items</b> are discussed at <b>Handling/Buttons</b>!
			<br><br>
			Whether and which of the following procedures are indicated, depends strongly on your Provider..
			<br><br>
			"<b>save_mode=off</b>" is a general basic condition.<br>
			"<b>ZLib Support=enabled</b>" is a basic condition for Backup and Restore.
			<br><br>			
			*<small>The administrator has additional extensive possibilities.
			The possibilities can be defined in "<b>config/<wbr>config.php</b>"!</small>
			</td></tr>
		</table>
		<br><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/copy_blobs.png" alt="copy_blobs" style="margin-right: 1em;" width="350" height="272" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Copy all Posters from DataBase to Server</b>!</big>
			<br><br>
			During this <b>procedure</b> you always see the <i>action indicator</i><br>
			<img src="help/en/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>independently of what you have selected at <b>"Edit basic Configuration"</b> 
			<b>"Use the Progress Indicator"</b>!
			<br><br>
			<small>If necessary, all actions of this operation are written into the log file.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/copy_poster.png" alt="copy_poster" style="margin-right: 1em;" width="350" height="286" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Copy all Posters from Server to DataBase</b>!</big>
			<br><br>
			During this <b>procedure</b> you always see the <i>action indicator</i><br>
			<img src="help/en/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>independently of what you have selected at <b>"Edit basic Configuration"</b> 
			<b>"Use the Progress Indicator"</b>!
			<br><br>
			<small>If necessary, all actions of this operation are written into the log file.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/extract_blobs.png" alt="extract_blobs" style="margin-right: 1em;" width="350" height="272" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Extract all Posters from DataBase and save to Server</b>!</big>
			<br><br>
			Whether you get to see a <i>progress indicator</i><br> 
			<img src="help/en/images/progess_ind.png" align="center" alt="progess" width="202" height="18" border="0">
			<br>or an <i>action indicator</i><br>
			<img src="help/en/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>during this <b>procedure</b> depends on what you have selected at <b>"Edit basic Configuration"</b> 
			<b>"Use the Progress Indicator"</b>!
			<br><br>
			<small>If necessary, all actions of this operation are written into the log file.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/extract_poster.png" alt="extract_poster" style="margin-right: 1em;" width="350" height="286" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Extract all Posters from Server and save to DataBase</b>!</big>
			<br><br>
			Whether you get to see a <i>progress indicator</i><br> 
			<img src="help/en/images/progess_ind.png" align="center" alt="progess" width="202" height="18" border="0">
			<br>or an <i>action indicator</i><br>
			<img src="help/en/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>during this <b>procedure</b> depends on what you have selected at <b>"Edit basic Configuration"</b> 
			<b>"Use the Progress Indicator"</b>!
			<br><br>
			<small>If necessary, all actions of this operation are written into the log file.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/clear_blobs.png" alt="clear_blobs" style="margin-right: 1em;" width="350" height="272" border="0">
			</td><td valign="top" class="txt">	
			<big><b><strong>Clear</strong> all Posters in the DataBase</b>!</big>
			<br><br>
			Whether you get to see a <i>progress indicator</i><br> 
			<img src="help/en/images/progess_ind.png" align="center" alt="progess" width="202" height="18" border="0">
			<br>or an <i>action indicator</i><br>
			<img src="help/en/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>during this <b>procedure</b> depends on what you have selected at <b>"Edit basic Configuration"</b> 
			<b>"Use the Progress Indicator"</b>!
			<br><br>
			<small>If necessary, all actions of this operation are written into the log file.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/delete_poster.png" alt="delete_poster" style="margin-right: 1em;" width="350" height="272" border="0">
			</td><td valign="top" class="txt">	
			<big><b><strong>Delete</strong> all Posters on the Server</b>!</big>
			<br><br>
			Whether you get to see a <i>progress indicator</i><br> 
			<img src="help/en/images/progess_ind.png" align="center" alt="progess" width="202" height="18" border="0">
			<br>or an <i>action indicator</i><br>
			<img src="help/en/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>during this <b>procedure</b> depends on what you have selected at <b>"Edit basic Configuration"</b> 
			<b>"Use the Progress Indicator"</b>!
			<br><br>
			<small>If necessary, all actions of this operation are written into the log file.</small>
			</td></tr>
		</table>
		<br><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/backup_dbase.png" alt="backup_dbase" style="margin-right: 1em;" width="418" height="281" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Backup the whole DataBase as SQL to zip</b>!</big>
			<br><br>
			If you click on the button <span class="button">Start</span> 
			the requester is closed and a regular Download begins.
			<br><br>
			<small>The attitude of the maximum size of an uploadable file <i>(<b>upload_<wbr>max_<wbr>filesize</b>)</i>
			is only then of fundamental importance if this archives are again to be uploaded for restoring.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/backup_poster.png" alt="backup_poster" style="margin-right: 1em;" width="422" height="281" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Backup Poster files from Server to zip</b>!</big>
			<br><br>
			If you click on the button <span class="button">Start</span> 
			the requester is closed and a regular Download begins.
			<br><br>
			<small>The attitude of the maximum size of an uploadable file <i>(<b>upload_<wbr>max_<wbr>filesize</b>)</i>
			is only then of fundamental importance if this archives are again to be uploaded for restoring.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/backup_list.png" alt="backup_list" style="margin-right: 1em;" width="444" height="286" border="0">
			</td><td valign="top" class="txt">
			<b>The posters to download were distributed on several ZIP archives</b>, because your account permits only a limited upload file size!	
			<br><br>
			Click on the list entries to download the archives.
			Wait in each case until archives were completely downloaded, before you click on the next list entry.
			<br><br>
			If you processed all list entries click on the <span class="button">OK</span> button to close the requester.
			<br><br>			
			<small></small>
			</td></tr>
		</table>		
		<br><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/select_dbase.png" alt="select_dbase" style="margin-right: 1em;" width="404" height="233" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Load data base backup</b>!</big>
			<br><br>
			If you click on the <span class="button">Upload</span> button the requester will show an 
			<i>action indicator</i><br>
			<img src="help/en/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>while archives are uploaded.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/askfor_dbase.png" alt="askfor_dbase" style="margin-right: 1em;" width="404" height="233" border="0">
			</td><td valign="top" class="txt">
			<big><b>After the ZIP-<wbr>Archive were uploaded - this requester appears</b>.</big>
			<br><br>
			If you click on the <span class="button">Restore</span> button, the following requester appears.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/restore_dbase.png" alt="restore_dbase" style="margin-right: 1em;" width="350" height="272" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Restore the whole DataBase from Backup zip</b>!</big>
			<br><br>
			During this <b>procedure</b> you always see the <i>action indicator</i><br>
			<img src="help/en/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>independently of what you have selected at <b>"Edit basic Configuration"</b> 
			<b>"Use the Progress Indicator"</b>!
			<br><br>
			<small>If necessary, all actions of this operation are written into the log file.</small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/select_poster.png" alt="select_poster" style="margin-right: 1em;" width="404" height="233" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Load poster backup</b>!</big>
			<br><br>
			If you click on the <span class="button">Upload</span> button the requester will show an 
			<i>action indicator</i><br>
			<img src="help/en/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>while archives are uploaded.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/askfor_poster.png" alt="askfor_poster" style="margin-right: 1em;" width="404" height="233" border="0">
			</td><td valign="top" class="txt">	
			<big><b>After the ZIP-<wbr>Archive were uploaded - this requester appears</b>.</big>
			<br><br>
			If you click on the <span class="button">Restore</span> button, the following requester appears.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/restore_poster.png" alt="restore_poster" style="margin-right: 1em;" width="350" height="272" border="0">
			</td><td valign="top" class="txt">	
			<big><b>Restore Posters on Server from Backup zip</b>!</big>
			<br><br>
			During this <b>procedure</b> you always see the <i>action indicator</i><br>
			<img src="help/en/images/action_ind.png" align="center" alt="action" width="202" height="18" border="0">
			<br>independently of what you have selected at <b>"Edit basic Configuration"</b> 
			<b>"Use the Progress Indicator"</b>!
			<br><br>
			<small>If necessary, all actions of this operation are written into the log file.</small>
			</td></tr>
		</table>
		<br><br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/log_req.png" alt="log_req" style="margin-right: 1em;" width="422" height="357" border="0">
			</td><td valign="top" class="txt">	
			<big>You arrive this way, If you clicked <span class="button">Show&nbsp;Log&nbsp;file</span>
			in the <b>Preferences-<wbr>Requester</b>.</big>			
			<br><br>
			Each procedure begins with the <b class="green">LOG:</b>-Date and the <b class="green">CMD:</b>-Instruction!
			<br><br>
			<b class="blue">WARNING:</b> describes a warning, which does not have consequences!
			<br><br> 
			<b class="red">ERROR:</b> describes an error!
			<br><br>
			If necessary, the <b>log file</b> can be emptied by a click on <span class="button">Clear</span>.
			</td></tr>
		</table>
	</td></tr>
</table>
<br>