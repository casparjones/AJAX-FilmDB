<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Views</b></h1>
		<h2><b>Different Data Views</b></h2>
	</td></tr>
	<tr><td class="txt">
		If you click in the upper <b>operating area</b> on one of the four <b>view graphics</b> 
		you will get the following data views:<br><br>
		<p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/list_view.png" alt="List-View" style="margin-right: 1em;" width="400" height="232" border="0">
			</td><td valign="top" width="26" height="24">
				<img src="help/images/button/list_on.png" alt="List" width="26" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>List-View</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			This <b>view</b> shows a middle information density in order 
			to accommodate as much as possible <b>films</b> per page.
			<br><br>
			If you are logged in as a user you can <i>(by click on this <b>button</b>)</i>...
			<br><br>
			<table border="0" cellpadding="0" cellspacing="0"><tr><td valign="top" width="14" height="14">
				<img src="help/images/edit_off.png" title="Edit this Film!" alt="Edit" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Edit this Film!</span>
			</td></tr></table>
			<br>
			...edit <b>the selected film</b>.
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/lent_req.png" alt="Filmstatus" style="margin-right: 1em;" width="310" height="283" border="0">
			</td><td valign="top" class="txt">
			If you are logged in as a user you can <i>(by click on one of this two <b>buttons</b>)</i>
			<br><br>
			<table border="0" cellpadding="0" cellspacing="0"><tr><td valign="top" width="14" height="14">
				<img src="help/images/avail_is.png" title="available" alt="Avail" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">available</span>
			</td></tr><tr><td colspan="2" height="4"></td></tr><tr><td valign="top" width="14" height="14">
				<img src="help/images/avail_no.png" title="loaned" alt="Avail" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Loaned to XXXX at 01-Jan-2005</span>
			</td></tr></table>
			<br>
			...edit the <b>film status</b>.
			<br><br>
			<big>This <b>Requester</b> serves to adapt the <b>film status</b> 
			to the current situation!</big>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" class="txt">
			If you drive with the <b>mouse over</b> the <b>miniature poster</b> at the right edge 
			of the page a <b>Tooltip with</b> the <b>poster</b> in original dimension <b>appears</b>!
			<br><br>
			A click on a <b>miniature poster</b> will open the IMDb page of the 
			selected film <i>(in a new browser window)</i>.
			<br><br>
			<big><b>The Tooltips appears only if "Without Posters in the List-View!" 
			is set to OFF in the configuration.</b></big>
			<br><br>
			Otherwise instead of the <b>miniature poster</b> only <b>simple reference graphics</b> are indicated...
			<br><br>
			<table border="0" cellpadding="0" cellspacing="0"><tr><td valign="top" width="14" height="14">
				<img src="help/images/link.png" title="IMDb-Seite" alt="IMDb" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Show the IMDb-Page of this Film!</span>
			</td></tr></table>
			</td><td valign="top">
				<img src="help/en/images/tooltip.png" alt="Tooltip" style="margin-left: 1em;" width="105" height="179" border="0">
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/poster_view.png" alt="Poster-View" style="margin-right: 1em;" width="400" height="232" border="0">
			</td><td valign="top" width="26" height="24">
				<img src="help/images/button/poster_on.png" alt="Poster" width="26" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Poster-View</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			This <b>view</b> shows the <b>film posters</b> and <b>local titles</b> only.
			<br><br>
			If you are logged in as a user you can <i>(by click on this <b>button</b>)</i>...
			<br><br>
			<table border="0" cellpadding="0" cellspacing="0"><tr><td valign="top" width="14" height="14">
				<img src="help/images/edit_off.png" title="Edit this Film!" alt="Edit" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Edit this Film!</span>
			</td></tr></table>
			<br>
			...edit <b>the selected film</b>.
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/row_view.png" alt="Row-View" style="margin-right: 1em;" width="400" height="232" border="0">
			</td><td valign="top" width="26" height="24">
				<img src="help/images/button/row_on.png" alt="Row" width="26" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Row-View</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			This <b>view</b> shows only a few <b>films</b> per page in order 
			to accommodate all relevant information.
			<br><br>
			If you are logged in as a user you can <i>(by click on this <b>button</b>)</i>...
			<br><br>
			<span class="button">Edit</span>
			<br><br>
			...edit <b>the selected film</b>.
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/film_view.png" alt="Film-View" style="margin-right: 1em;" width="400" height="232" border="0">
			</td><td valign="top" width="25" height="24">
				<img src="help/images/button/film_on.png" alt="Film" width="25" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Film-View</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			This <b>view</b> shows only one <b>film</b> per page in order
			to accommodate all stored information.
			<br><br>
			If you are logged in as a user you can <i>(by click on this <b>button</b>)</i>...
			<br><br>
			<span class="button">Edit</span>
			<br><br>
			...edit <b>the selected film</b>.
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/list_php.png" alt="List-View" style="margin-right: 1em;" width="366" height="172" border="0">
			</td><td>&nbsp;</td><td valign="top" class="txt">
				<big><b>Incompatible Browsers</b></big><br><br>
			This <b>View</b> is meant for incompatible or old Browsers only <i>(JavaScript must be activated)</i>.
			Thus at least the most important information can be still sighted.
			<br><br>
			You can reach this <b>View</b> by the <b>URL</b>...
			<br><br>
			<img src="help/images/list_url.png" alt="URL" width="200" height="16" border="0">
			<br><br>
			...replace <b>localhost</b> by your personal Domain!
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/images/mobile.png" alt="Mobile-View" style="margin-right: 1em;" width="170" height="442" border="0">
			</td><td>&nbsp;</td><td valign="top" class="txt">
				<big><b>PDA and Mobile Phone</b></big><br><br>
			This <b>View</b> is meant for HTML-ABLE mobile telephones and PDAs only.
			Thus at least the most important information can be still sighted <i>(sorted according to date)</i>.
			<br><br>
			You can reach this <b>View</b> by the <b>URL</b>...
			<br><br>
			<img src="help/images/mobile_url.png" alt="URL" width="204" height="16" border="0">
			<br><br>
			...replace <b>localhost</b> by your personal Domain!
			</td><td>&nbsp;</td><td valign="top" rowspan="2">
				<img src="help/en/images/rss.png" alt="RSS-View" style="margin-left: 1em;" width="199" height="440" border="0">
			</td></tr><tr><td>&nbsp;</td><td align="right" valign="bottom" class="txt">
				<big><b>RSS Feed</b></big><br><br>
			This <b>View</b> is for RSS readers only.
			Shows the 10 newest Movies in the Film DataBase.
			<br><br>
			You can reach this <b>View</b> by the <b>URL</b>...
			<br><br>
			<img src="help/images/rss_url.png" alt="URL" width="180" height="16" border="0">
			<br><br>
			...replace <b>localhost</b> by your personal domain and <b>http:</b> coul'd also be <b>feed:</b>!
			<td>&nbsp;</td></td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>