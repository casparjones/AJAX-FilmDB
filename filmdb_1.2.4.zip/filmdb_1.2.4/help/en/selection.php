<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Select</b></h1>
		<h2><b>Fixed Selections</b></h2>
	</td></tr>
	<tr><td class="txt">
		The upper right <b>operating area</b> in the <b>IFrame</b> makes
		the following possibilities available:<br>
		<span class="tooltype"><small>The current Selection has always a BLUE background.</small></span>
		<br>
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<img src="help/en/images/select_area.png" alt="Select" width="525" height="20" border="0">
			</td></tr><td class="txt">
			<dl>
				<dt><big><b>All</b></big></dt>
				<dd>
				<b>General listing of all films in the data base</b>!<br>
				All entries/modifications made in the search requester
				will be reset to the pre-setting.
				</dd>
				<dt><br><big><b>0-9</b></big></dt>
				<dd>
				<b>Listing of all films which do not begin with a letter</b>!<br>
				All entries/modifications made in the search requester
				will be reset to the pre-setting.
				</dd>
				<dt><br><big><b>A - Z</b></big></dt>
				<dd>
				<b>Listing of all films which do begin with the selected letter</b>!<br>
				All entries/modifications made in the search requester
				will be reset to the pre-setting.
				</dd>
			</dl>
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>