<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>API(s)</b></h1>
	</td></tr>
	<tr><td class="txt">	
		<dl><dt><nobr><big><b>Export</b></big></nobr></dt>
			<dd>In order to be able to access the data base from other programs,
			a <b>simple API</b> is provided. The API is accessable via <b>GET</b> 
			and/or via <b>POST</b>. After a successful call a well formed and valid
			<b>XML stream</b> or a <b>XML file</b> will be returned. 
			<br><small><br></small>
			<b>Syntax</b>:<ul>
				<li>path: <code> export.php</code></li>
				<li>query: <code> ?imdb_id= </code><small>([0-9]{7})</small><br>
				<span style="color:green;">original id from Internet Movie Data base</span>
				<br><i>...or...</i><br>
				query: <code> ?file_id= </code><small>([0-9]{*})</small><br>
				<span style="color:green;">original id from MySQL Data base</span></li>
				<li>subquery: <code> &amp;stream= </code><small>(true|false)</small><br>
				<span style="color:green;">returns a stream or an downloadable file</span>
				<br><i>...optional...</i><br></li>
				<li>subsubquery: <code> &amp;dtd= </code><small>(internal|external)</small><br>
				<span style="color:green;">Document Type Declaration internally or externally referenced or none</span></li>
			</ul><small><br></small>
			<b>Errorcodes</b>:<ul>
				<li><code>error: no movie id</code></li>
				<li><code>error: unknown movie id</code></li>
			</ul>
		</dd></dl>
	</td></tr>
</table>
<br>