<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Buttons</b></h1>
		<h2><b>Different Buttons</b></h2>
	</td></tr>
	<tr><td class="txt">
		If you click in the upper <b>operating area</b> on one of the right lying 
		buttons, you get access to following functions:<br><br>
		<p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/add_req.png" alt="Add Film" style="margin-right: 1em;" width="346" height="220" border="0">
			</td><td width="30" height="24" valign="top">
				<img src="help/images/button/plus_on.png" alt="Add" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Add new Film</b>*</big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Enter the <b>original title</b> of the film you 
			would like to add to the data base and click on <b>Search</b>!
			<br><br>
			<small>If you don't know the <b>original title</b> you can 
			determine these simply by the following input into a 
			<b>search engine</b>:<br><br></small>
			<strong>film "XXXXXX" original title</strong>
			<small><br><br>Whereby XXXXXX is the 
			already known <b>title</b>.</small>
			<br><br>
			*<small>Logged users only.<small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/movie_req.png" alt="Select Film" style="margin-right: 1em;" width="438" height="382" border="0">
			</td><td valign="top" class="txt">
				If this Requester appears the search procedure on <b>IMDb</b>
				<i>(Internet Movie Database)</i> is final.
				<br><br>
				The found films are sorted according to priority. Thus the top film 
				is also usually the correct one.
				<br><br>
				If you click on one of the <b>IMDb</b> images - visible on the right side of each line - 
				you could <i>(e.g. for control purposes)</i> open the <b>IMDb</b> page of the named film
				<i>(in a new browser window)</i>.
				<br><br>
				<b>Select</b> a film <b>by clicking</b>!
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/import_req.png" alt="Import Film" style="margin-right: 1em;" width="404" height="222" border="0">
			</td><td width="30" height="24" valign="top">
				<img src="help/images/button/import_on.png" alt="Import" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Import new Film</b>*</big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Select the <b>XML file</b> of the film, which you would like 
			to add to the data base and click on <b>Import</b>!
			<br><br>
			*<small>Logged users only.<small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/importask_req.png" alt="Import Film" style="margin-right: 1em;" width="364" height="322" border="0">
			</td><td valign="top" class="txt">
				If this Requester appears, the import procedure is verified.
				<br><br>
				If the determined film is already present in the data base, 
				a <b style="color:red;">RED</b> text indicates that to you.
				<br><br>
				If you click on the <b>IMDb</b> number 
				you could <i>(e.g. for control purposes)</i> open the 
				<b>IMDb</b> page of the named film
				<i>(in a new browser window)</i>.
				<br><br>
				Click on <b>Import</b> to finalize the procedure!
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/print_req.png" alt="Print Database" style="margin-right: 1em;" width="380" height="292" border="0">
			</td><td valign="top" width="30" height="24">
				<img src="help/images/button/print_on.png" alt="Print" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Print Database</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			Select the view of the data <i>(whether film-, row-, poster or list view)</i>
			and click on the <b>Print</b> button to generate a new browser window
			<i>(for printing)</i>!
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/print_win.png" alt="Print" style="margin-right: 1em;" width="340" height="187" border="0">
			</td><td valign="top" class="txt">
			The Print <b>corresponds</b> as far as useful to the <b>contents of the IFrame</b>.
			<br><br>
			The difference consists on the fact that the selection made by you 
			<i> (e.g. only films begining with an "A" or only films containing 
			the word "love" in the title)</i> is shown completely in a single browser page.
			<br><br>
			Select the menu item "<b>Print...</b>" in the pulldown menu of your browser
			to print the page!
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/statistic_req.png" alt="Database Statistics" style="margin-right: 1em;" width="335" height="329" border="0">
			</td><td width="30" height="24" valign="top">
				<img src="help/images/button/info_on.png" alt="Info" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Database Statistics</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			This <b>Requester</b> informs about the <b>most important</b>
			statistic informations of the <b>data base</b>!
			<br><br>
			Particularly the indication concerning the memory extent 
			of the data base is important for all those which got a 
			<b>volume delimitation</b> of the <b>MySQL data base</b> by their Provider.
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/cookiepref_req.png" alt="Prefs" style="margin-right: 1em;" width="374" height="427" border="0">
			</td><td width="30" height="24" valign="top">
				<img src="help/images/button/prefs_on.png" alt="Prefs" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Preferences</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			This <b>Requester</b> serves to <b>adapt</b> the <b>program</b> 
			to the personal needs of each individual visitor!
			<br><br>
			<big><b>*Unlogged users branches out to this requester</b></big>.
			<br><br>
			To store individual program configurations your browsers config 
			has to be set at least to...<br><br>
			"<b>accept Cookies</b>" and<br>
			"<b>only from the original Website</b>"
			<br><br>
			*<small>Guests may view and print all film-views and 
			store their own browser specific configuration.<small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/user_req.png" alt="Configuration" style="margin-right: 1em;" width="365" height="237" border="0">
			</td><td valign="top" class="txt">
			<big><b>You arrive at the above requester</b> 
			if you click the <span class="button">Program</span> button or click the 
			entry <small><b>"Edit Program Configuration"</b></small> as an Admin.</big>
			<br><br>
			<big><b>*Logged Users branches out to this requester</b></big>.
			<br><br>
			*<small>Logged users may work additionally on the list of borrower
			and could add, edit and delete films as well.<small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/borrower_req.png" alt="Borrowerlist" style="margin-right: 1em;" width="350" height="372" border="0">
			</td><td valign="top" class="txt">
			<big><b>You arrive this way</b> if you've clicked the <span class="button">Borrower</span> 
			button or as an Admin the entry <small><b>"Edit List of Borrower"</b></small>
			in the <b>preferences requester</b>.</big>
			<br><br>
			Logged users can <b>add/edit</b> the <b>List of Borrower</b>
			but they are <b>unable to delete</b> entries!
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/admin_req.png" alt="Configuration" style="margin-right: 1em;" width="444" height="503" border="0">
			</td><td valign="top" class="txt">
			<big><b>*The Administrator branches out to this requester</b></big>.
			<br><br>
			More to this topic at <b>Handling/Admin</b>
			<br><br>
			*<small>Admins may work additionally on the 
			basic adjustment and the list of users.<small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/member_req.png" alt="Userlist" style="margin-right: 1em;" width="330" height="372" border="0">
			</td><td valign="top" class="txt">
			<big><b>You arrive this way</b> if you've clicked 
			the entry <small><b>"Edit List of Users"</b></small>
			in the <b>preferences requester</b>.</big>
			<br><br>
			Only the <b>logged in administrator</b> can edit the <b>List of Users</b>!
			<br><br>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/config_req.png" alt="Config" style="margin-right: 1em;" width="378" height="434" border="0">
			</td><td valign="top" class="txt">
			<big><b>You arrive this way</b> if you've clicked the 
			entry <small><b>"Edit Basic Configuration"</b></small>
			in the <b>preferences requester</b>.</big>
			<br><br>
			Only the <b>logged in administrator</b> can edit the <b>basic adjustment</b> 
			of the program!
			<br><br>
			Each Browser which does not accept Cookies falls back to this basic adjustment.
			<br><br>
			If the item... 
			<br><br>
			"<b>The posters will be stored in the data base as binary data!</b>"
			<br><br>
			...is off, 
			from now on all film posters will be saved as <b>files</b> 
			<i>(Pattern: [0-9]{*}.pic)</i> in the directory
			"<b>poster/</b>" and not as <b>blobs</b> in the data base.
			<br><br>
			<small>
			FilmDB will search in both sources for posters, therefore mixed processing is possible.
			Blobs and files have both their pro and cons. Whose account supports only little MySQL space
			will change over to files, even if thereby the Backup's are incomplete via phpMyAdmin (without posters).			
			</small>			
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/login_req.png" alt="Login" style="margin-right: 1em;" width="357" height="221" border="0">
			</td><td valign="top" width="30" height="24">
				<img src="help/images/button/login_on.png" alt="Login" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Login</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			To announce as a user or administrator enter your <b>user name</b> and your 
			<b>password</b> and click on <b>OK</b>!
			<br><br>
			<big>The <b>password delivery</b> does not take place in plain text
			it is always coded with...</big>
			<br><br>
			<b>MD5</b> <i>(Message-Digest Algorithm)</i>
			<br><br>
			<small>The lock symbol changes from color
			<b style="color:green;">GREEN</b> to <b style="color:red;">RED</b>.<small>
			</td></tr>
		</table>
		<br>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/logout_req.png" alt="Logout" style="margin-right: 1em;" width="294" height="243" border="0">
			</td><td valign="top" width="30" height="24">
				<img src="help/images/button/logout_on.png" alt="Logout" width="30" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Logout</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			You are now <b>logged out</b>!
			<br><br>
			<small>The lock symbol changes from color
			<b style="color:red;">RED</b> again to <b style="color:green;">GREEN</b>.<small>
			</td></tr>
		</table>
		</p><br><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top" rowspan="2">
				<img src="help/en/images/help_mode.png" alt="Help" style="margin-right: 1em;" width="400" height="232" border="0">
			</td><td valign="top" width="24" height="24">
				<img src="help/images/button/help_on.png" alt="Help" width="24" height="24" border="0">
			</td><td>&nbsp;</td><td class="txt">
				<big><b>Online-Help</b></big>
			</td></tr><td colspan="3" valign="top" class="txt"><br>
			<big><b>You are <strong>HERE</strong></b>!</big>
			<br><br>
			The <b>Online-Help</b> describes the most important parameters.
			Actually a more powerful documentation should be unnecessary due 
			to the self-describing user interface <i>(Tooltips)</i>.
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>