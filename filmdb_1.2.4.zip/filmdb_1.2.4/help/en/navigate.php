<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Navigate</b></h1>
		<h2><b>Navigation and Viewpanel</b></h2>
	</td></tr>
	<tr><td class="txt">
		The lower <b>operating area</b> in the <b>IFrame</b> makes 
		the following possibilities available:<br><br>
		<p>
		<table border="0" cellpadding="0" cellspacing="4">
			<tr><td>
				<img src="help/en/images/navig_area.png" alt="Navig" width="135" height="20" border="0">
			</td></tr><td class="txt">
			<dl>
				<dt><img src="help/images/button/first_on.png" alt="First" width="10" height="10" border="0"></dt>
				<dd>
				Jumps to the <b>beginning</b> of the available films.
				</dd>
				<dt><br><img src="help/images/button/prev_on.png" alt="Previous" width="10" height="10" border="0"></dt>
				<dd>
				Jumps <b>backward</b> by the number of visible films per page
				<i>(which was saved in the <b>program config</b> of the visitor/user)</i>.
				</dd>
				<dt><br><img src="help/images/button/next_on.png" alt="Next" width="10" height="10" border="0"></dt>
				<dd>
				Jumps <b>forward</b> by the number of visible films per page
				<i>(which was saved in the <b>program config</b> of the visitor/user)</i>.
				</dd>
				<dt><br><img src="help/images/button/last_on.png" alt="Last" width="10" height="10" border="0"></dt>
				<dd>
				Jumps to the <b>end</b> of the available films.
				</dd>
				<dt><br><b>1-8</b> of <b>8</b></dt>
				<dd>
				<b>Numeric announcement of the current listing of the films</b>!<br>
				<b>n-n</b> indicates the selection of the currently visible films, 
				and <b>of n</b> the absolute number of films.<br>
				The number of films visible per page can be saved 
				in the <b>program config</b> individually by each visitor.
				</dd>
			</dl>
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>