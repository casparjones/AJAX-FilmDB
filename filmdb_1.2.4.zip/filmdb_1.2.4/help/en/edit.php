<table id="printblock" border="0" cellpadding="0" cellspacing="0">
	<tr><td>
		<h1 id="print"><b>Edit</b></h1>
		<h2><b>Add/Edit Films</b></h2>
	</td></tr>
	<tr><td class="txt">
		If you are logged in as a user you can <b>edit</b> the selected film <b>by one click</b> on these
			<table style="display:inline;" border="0" cellpadding="0" cellspacing="0"><tr><td valign="top" width="14" height="14">
				<img src="help/images/edit_off.png" title="Edit Film" alt="Edit" width="14" height="14" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Edit this Film!</span>
			</td></tr></table>
			or this <span class="button">Edit</span> <b>button</b>.<br><br>
		<p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/addedit_req.png" alt="Edit" style="margin-right: 1em;" width="400" height="289" border="0">
			</td><td valign="top" class="txt">
			The <b>treatment</b> of a film is divided into <b>9 blocks of themes</b>.
			<br><br>
			The representation wraps <i>(similar to the <b>Poster View</b>)</i> automatically
			so the available space is always used optimally.
			</td></tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/media_area.png" alt="Media" style="margin-right: 1em;" width="222" height="183" border="0">
			</td><td valign="top" class="txt">
			The first <b>block of themes</b> is the only one which you should <b>fill out</b>
			conscientiously. All other data were determined already automatically <i>(exception: <b>local title</b>)</i>.
			<br><br>
			<b>Select a medium</b> and the program will reserve all settings 
			independently with meaningful values. Without a selected <b>language</b> 
			the film cannot be stored in the data base!
			<br><br>
			See the <b>spectrum of popup requesters</b> with all available setting values!
			</td><td valign="top">
				<img title="Media" src="help/images/reqs/media_req.png" alt="Media" style="margin-left: 1em;" width="81" height="162" border="0">
			</tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="bottom" nowrap>
				<img title="Type" src="help/images/reqs/type_req.png" alt="Type" style="margin-right: 0.25em;" width="58" height="107" border="0">
				<img title="Container" src="help/images/reqs/cont_req.png" alt="Container" style="margin-right: 0.25em;" width="71" height="107" border="0">
				<img title="Video-Codec" src="help/images/reqs/vcodec_req.png" alt="Video-Codec" style="margin-right: 0.25em;" width="71" height="118" border="0">
				<img title="Format" src="help/images/reqs/format_req.png" alt="Format" style="margin-right: 0.25em;" width="59" height="129" border="0">
				<img title="Aspect-Ratio" src="help/images/reqs/aspect_req.png" alt="Aspect-Ratio" style="margin-right: 0.25em;" width="82" height="74" border="0">
				<img title="Audio-Codec" src="help/images/reqs/acodec_req.png" alt="Audio-Codec" style="margin-right: 0.25em;" width="66" height="118" border="0">
				<img title="Channel" src="help/images/reqs/channel_req.png" alt="Channel" style="margin-right: 0.25em;" width="47" height="129" border="0">
				<img title="Frequencies" src="help/images/reqs/freq_req.png" alt="Frequencies" width="53" height="74" border="0">
			</tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/title_area.png" alt="Title" style="margin-right: 1em;" width="222" height="183" border="0">
			</td><td valign="top" class="txt">
			In the second <b>block of themes</b> the <b>local title</b> must be filled manually
			since this information cannot yet be determined automatically.
			<br><br>
			According to standard the <b>local title</b> is filled with a copy of the <b>original title</b>.
			Without a <b>local title</b> the film cannot be stored in the data base!
			<br><br>
			<small>If you don't know the <b>local title</b> 
			you can determine these simply by the following input into a
			<b>search engine</b>:<br><br></small>
			<strong>film "XXXXXX" english title</strong>
			<small><br><br>Whereby XXXXXX is the
			already known <b>title</b>.</small>
			</td></tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/info_area.png" alt="Infos" style="margin-right: 1em;" width="222" height="183" border="0">
			</td><td valign="top" class="txt">
			In the second <b>block of themes</b> the film can be <b>lent</b> directly.
			The date is set to the current day. You have to set the borrower manually.
			<br><br>
			According to standard the date is set in reverse order.
			First the <b>year</b>, then the <b>month</b> and at the end the <b>day</b>.
			<b>Separator</b> is the minus sign.
			<br><br>
			<small>A logged user can work on and around the <b>list of the borrowers</b> 
			at any time.</small>
			</td></tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/poster_url_req.png" alt="Edit" style="margin-right: 1em;" width="416" height="221" border="0">
			</td><td valign="top" class="txt">
			This <b>requester</b> appears if you click on the following <b>Button in the Posterarea</b>.
			<br><br>
			<table style="display:inline;" border="0" cellpadding="0" cellspacing="0"><tr><td valign="top">
				<img src="help/images/poster/url.png" title="Upload" alt="Edit" width="32" height="32" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Upload</span>
			</td></tr></table>
			<br><br>
			Hereby you can assign another <b>poster</b> to the film.
			</td></tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/poster_file_req.png" alt="Edit" style="margin-right: 1em;" width="404" height="222" border="0">
			</td><td valign="top" class="txt">
			This <b>requester</b> appears if you click on the following <b>Button in the Posterarea</b>.
			<br><br>
			<table style="display:inline;" border="0" cellpadding="0" cellspacing="0"><tr><td valign="top">
				<img src="help/images/poster/upload.png" title="Upload" alt="Edit" width="32" height="32" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Upload</span>
			</td></tr></table>
			<br><br>
			Hereby you can assign another <b>poster</b> to the film.
			</td></tr>
		</table>
		</p><br><p>
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/poster_clear_req.png" alt="Edit" style="margin-right: 1em;" width="320" height="186" border="0">
			</td><td valign="top" class="txt">
			This <b>requester</b> appears if you click on the following <b>Button in the Posterarea</b>.
			<br><br>
			<table style="display:inline;" border="0" cellpadding="0" cellspacing="0"><tr><td valign="top">
				<img src="help/images/poster/clear.png" title="Clear" alt="Edit" width="32" height="32" border="0">
			</td><td>
				&nbsp;<span class="tooltype">Clear</span>
			</td></tr></table>
			<br><br>
			Hereby you can assign a <b>dummy poster</b> to the film.
			The <b>original poster</b> will be deleted <i>(blob and/or file)</i>!
			</td></tr>
		</table>
		</p><br><p>			
		
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/people_req.png" alt="Edit" style="margin-right: 1em;" width="438" height="382" border="0">
			</td><td valign="top" class="txt">
			This <b>requester</b> appears if you change the <b>name</b> of a person and 
			several persons with this name exist or if no suitable entry were found.
				<br><br>
				The found persons are sorted according to relevance.
				<br><br>
				If you click on one of the <b>IMDb</b> images - visible on the right side of each line -
				you could <i>(e.g. for control purposes)</i> open the <b>IMDb</b> page
				of the named person <i>(in a new browser window)</i>.
				<br><br>
				<b>Select</b> a person by <b>clicking</b>!
			</td></tr>
		</table>
		</p><br><br><p>	
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/exportask_req.png" alt="Export" style="margin-right: 1em;" width="364" height="337" border="0">
			</td><td valign="top" class="txt">
			<big><b>You arrive this way</b> if you've clicked the <span class="button">Export</span> 
			button in the 'User Mode: <b>EDIT</b>'.</big>
			<br><br>
			Select if a <b>DTD</b> is to be provided with the export. 
			If yes, which!
			<br><br>
			Should the <b>DTD</b> to be included into each <b>XML file</b>
			<em>(internally)</em>, or should the <b>DTD</b> only be referred by one
			additional line <em>(externally)</em>?
			<br><br>
			Without <b>DTD</b> the document is probably well formed 
			<em>(is enough for the in/export in FilmDB)</em>, but not valid.
			<br><br>
			<small><b>DTD</b> = Document Type Description</small>
			</td></tr>
		</table>
		<br>	
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/rescanask_req.png" alt="Rescan" style="margin-right: 1em;" width="364" height="270" border="0">
			</td><td valign="top" class="txt">
			<big><b>You arrive this way</b> if you've clicked the <span class="button">Rescan</span> 
			button in the 'User Mode: <b>EDIT</b>'.</big>
			</td></tr>
		</table>
		<br>	
		<table border="0" cellpadding="0" cellspacing="0">
			<tr><td valign="top">
				<img src="help/en/images/deleteask_req.png" alt="Delete" style="margin-right: 1em;" width="364" height="270" border="0">
			</td><td valign="top" class="txt">
			<big><b>You arrive this way</b> if you've clicked the <span class="button">Delete</span> 
			button in the 'User Mode: <b>EDIT</b>'.</big>
			</td></tr>
		</table>
		</p>
	</td></tr>
</table>
<br>