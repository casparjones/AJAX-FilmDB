<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
       "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
		<title>FilmDB</title>
		<meta http-equiv="Content-Style-Type" content="text/css">
		<link rel="stylesheet" type="text/css" href="config/<?php if(eregi('Win',$_SERVER['HTTP_USER_AGENT'])) { echo "win"; } else { echo "oos"; } ?>.css">
		<style type="text/css" media="all">
		<!--
			body { margin: 1em; background-color: #ffffff; }
			a { text-decoration: none; font-weight: bold; color: #333333; }
			a:hover { text-decoration: none; font-weight: bold; color: #333333; cursor:pointer; }
			h1 { font-size:180%; color:#444; display:inline; }
			h1#item { font-size:160%; line-height:80%; color:#666; display:block; }
			h2 { font-size:160%; line-height:180%; color:#333; display:inline; }
			h2#item { font-size:140%; line-height:60%; color:#444; display:block; }
			h3 { font-size:140%; line-height:160%; color:#333; display:inline; }
			h4 { font-size:120%; line-height:140%; color:#333; display:inline; }
			h5 { font-size:100%; line-height:120%; color:#333; display:inline; }
			small { font-size:80%; }
			big { font-size:112%; }
			strong { color:#000000; }
			.txt { font-size: 92%; }
			.mial { font-weight:bold; }
			.mial:before { content: " youcan[]gmx.net"; }
			.display { display:inline; font-size:11px; width:160px; min-width:160px; height: auto; padding: 4px 8px 4px 8px; border-radius: 4px; -moz-border-radius: 4px; -khtml-border-radius: 4px; background-color: #bdcaac; }
			.tooltype { border:solid 1px #B4BAC3; font-size:10px; font-weight:bold; padding:1px 4px 1px 4px; background-color:#FEFECA; }
			.button { border-width:2px; border-color:lightgrey; border-style:outset; font-size:10px; font-weight:bold; padding:1px 8px 1px 8px; background-color:lightgrey; }
			.colbox { position: inline; top: 0px; left: 0px; width: 32px; height: 32px; margin: 0 1em 1em 0; border-radius: 8px; -moz-border-radius: 8px; -khtml-border-radius: 8px; }
			#printblock { page-break-after:always; min-width:700px; width:100%; }
			h1#print { font-size:180%; line-height:100%; color:#444; display:block; }
		-->
		</style>
	</head>
	<body>
