<?php
// define any number of users here; DO NOT DELETE the admin!
// users[i][md5pass] must contain the md5-encrypted password
$cfg['users'][0]['user'] = "admin";
$cfg['users'][0]['md5pass'] = "21232f297a57a5a743894a0e4a801fc3";
?>
