<?php
$cfg['language'] = "en";
$cfg['noofrows'] = 2;
$cfg['noofpics'] = 12;
$cfg['noofentries'] = 16;
$cfg['listheight'] = 256;
$cfg['use_progress'] = true;
$cfg['use_blob'] = true;
$cfg['nobreaks'] = false;
$cfg['original'] = true;
$cfg['noposter'] = false;
?>
