<?php
$cfg['mysql_host'] = 'localhost';
$cfg['mysql_user'] = 'name';
$cfg['mysql_pass'] = 'pass';
$cfg['mysql_db'] = 'filmdb';
?>
